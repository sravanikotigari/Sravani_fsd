package com.cts;

import java.util.ArrayList;
import java.util.List;

public class ListDemo {
	public static void main(String[] args) {
		List l=new ArrayList();
		l.add("hii");
		l.add(10);
		l.add("hii");
		l.add(20);
		l.add(null);
		l.add(10);
		l.add(null);
		System.out.println("data of list"+l);
	}

}
