package com.cts;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {
	public static void main(String[] args) {
		Set s=new HashSet();
		s.add("hii");
		s.add(123);
		s.add("hii");
		s.add(null);
		s.add(5);
		System.out.println("set items are"+s);
	}

}
