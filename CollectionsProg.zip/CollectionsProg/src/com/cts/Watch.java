package com.cts;

public class Watch {

	private float price;
	private String brand;
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Watch() {
		
	}
	public Watch(float price,String brand) {
		this.price=price;
		this.brand=brand;
	}
	@Override
	public String toString() {
		return "Watch [price=" + price + ", brand=" + brand + "]";
	}
	
}
