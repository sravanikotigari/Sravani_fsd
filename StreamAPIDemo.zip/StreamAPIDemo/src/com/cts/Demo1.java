package com.cts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Demo1 {
	public static void main(String[] args) {
		
		
		//integers from 1 to 5
		Stream.of(new Integer[] {1,2,3,4,5}).forEach(System.out::println);
		
		
		//adding to list
		List<Integer> list = new ArrayList<>();
		for(int i=0;i<=20;i+=2) {
			list.add(i);
		}
		list.stream().forEach(i->System.out.print(i+" "));
		
		
		
		
		
		  Integer a[] = {1,2,3,4,5,6,6,4,2,0}; List<Integer> list1 = Arrays.asList(a);
		   Set<Integer> mySet = list1.stream().collect(Collectors.toSet());
		  System.out.println(mySet);
		  
		  Stream<Integer> itr = Stream.iterate(45,p->p+5).limit(5);
		  itr.filter(i->i%5==0).forEach(System.out::println);
		 
	}

}
