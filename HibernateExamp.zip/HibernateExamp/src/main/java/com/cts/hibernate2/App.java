package com.cts.hibernate2;

import java.io.Serializable;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;


import com.cts.hibernate2.model.Employee;

public class App 
{
    public static void main( String[] args )
    {
         Configuration config=new Configuration().configure();
      StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(config.getProperties());       
      SessionFactory factory= config.buildSessionFactory(builder.build());
      Session session= factory.openSession();
      Employee employee = new Employee(1004,"rema","Manager");	
      session.beginTransaction();
    Serializable obj = session.save(employee);
  	session.getTransaction().commit();
  	session.close();
    }
}
