package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.ProductSpecifications;
import com.cg.capstore.entity.Rating;
import com.cg.capstore.exceptions.RatingException;
import com.cg.capstore.service.ICapstoreViewProductService;

@RestController
public class ViewProductController {

	@Autowired
	private ICapstoreViewProductService ser;

	/**
	 * @author Rebekah Jacinth
	 * @since 22/6/19
	 * @param pid
	 * @return Product instance
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "viewsingleprod/{id}", method = RequestMethod.GET)
	public Product viewby(@PathVariable("id") int pid) {
		return ser.getProduct(pid);
	}

	/**
	 * @author Rebekah Jacinth
	 * @since 22/6/19
	 * @param pid
	 * @return List
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "viewspec/{id}", method = RequestMethod.GET)
	public List<ProductSpecifications> viewspec(@PathVariable("id") int pid) {
		return ser.getSpecifications(pid);
	}

	/**
	 * @author Akhila Sivaraman
	 * @since 24/6/19
	 * @param pid
	 * @return List
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "viewrating/{id}", method = RequestMethod.GET)
	public List<Rating> viewrating(@PathVariable("id") int pid) {
		return ser.viewRating(pid);
	}

	/**
	 * @author Namratha Thakur
	 * @since 25/6/19
	 * @param review
	 * @param pid
	 * @param uid
	 * @return boolean
	 * @throws RatingException
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "addreview/{pid}/{uid}", method = RequestMethod.POST)
	public boolean addReview(@RequestBody Rating review, @PathVariable("pid") int pid, @PathVariable("uid") int uid)
			throws RatingException {
		ser.addRating(review, pid, uid);
		return true;
	}

	/**
	 * @author Kumari
	 * @since 25/6/19
	 * @param catId
	 * @return List
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "viewsimilar/{id}", method = RequestMethod.GET)
	public List<Product> viewSimilarProduct(@PathVariable("id") int catId) {
		return ser.similarProducts(catId);
	}

	/**
	 * @author Akhila Sivaraman
	 * @since 24/6/19
	 * @param pid
	 * @return
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "avgrating/{id}", method = RequestMethod.GET)
	public float averageRating(@PathVariable("id") int pid) {
		Float rating = ser.averageRating(pid);
		if (rating == null)
			rating = 0.0f;
		return rating;

	}

}
