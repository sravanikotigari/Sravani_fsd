package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capstore.entity.CartDetails;

public interface ICartDetailsDao extends JpaRepository<CartDetails,Integer>{
	
	@Query("select cart from CartDetails cart left join fetch cart.user u where u.userId=:userid and cart.status=1")
	 List<CartDetails> viewCartDetails(@Param("userid") int userId);
	
	@Modifying
	@Query("update CartDetails cd set cd.order.orderId=:orderid, cd.status=0 where cd.user.userId=:userid and cd.status=1")
	void updateOrderIDInCart(@Param("orderid") int orderId, @Param("userid") int userId);
	
	@Query("select cd from CartDetails cd left join fetch cd.order od where cd.user.userId=:userid")
	List<CartDetails> viewDeliveryStatus(@Param("userid") int userId); 
	
	@Query("select cart from  CartDetails cart inner join fetch cart.product p inner join cart.order od where od.orderId=:oid")
    public List<CartDetails> getOrderedProducts(@Param("oid") int oid);
	
	
	
}
