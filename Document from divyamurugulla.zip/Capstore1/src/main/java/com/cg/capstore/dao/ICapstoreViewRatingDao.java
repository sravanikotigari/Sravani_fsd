package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.Rating;

public interface ICapstoreViewRatingDao extends JpaRepository<Rating, Integer> {

	/**
	 * @author Akhila Sivaraman
	 * @since 24/6/19
	 * This query is used to get the reviews for given product
	 * @param pid 
	 * @return List
	 */
	@Query("select review from Rating review left join fetch review.prods prd where prd.productId=:pid order by review.ratingId desc")
	public List<Rating> viewRating(@Param("pid") int pid);
	
	/**
	 * @author Akhila Sivaraman
	 * @since 24/6/19
	 * This query is used to get the average rating for given product
	 * @param prod - Product instance 
	 * @return Float
	 */
	@Query("select avg(review.rating) from Rating review where prods=:prod")
	public Float averageRating(@Param("prod") Product prod);
	
}
