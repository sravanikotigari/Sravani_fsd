package com.cg.capstore.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_order")
public class OrderDetails {

	@Id
	@Column(name = "order_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderId;

	@Column(name = "order_date")
	private LocalDate date;

	@Column(length = 50)
	private String address;

	@Column(name = "cust_state", length = 50)
	private String state;

	@Column(length = 50)
	private String city;

	@Column(length = 50)
	private String deliveryStatus;

	@Column(name = "payment_mode", length = 50)
	private String paymentMode;

	public OrderDetails() {

	}

	public OrderDetails(int orderId, LocalDate date, String address, String state, String city, String deliveryStatus,
			String paymentMode) {
		super();
		this.orderId = orderId;
		this.date = date;
		this.address = address;
		this.state = state;
		this.city = city;
		this.deliveryStatus = deliveryStatus;
		this.paymentMode = paymentMode;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDeliveryStatus() {
		return deliveryStatus;
	}

	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	@Override
	public String toString() {
		return "OrderDetails [orderId=" + orderId + ", date=" + date + ", address=" + address + ", state=" + state
				+ ", city=" + city + ", deliveryStatus=" + deliveryStatus + ", paymentMode=" + paymentMode + "]";
	}

	@Override
	public int hashCode() {

		return orderId;
	}

	@Override
	public boolean equals(Object obj) {
		OrderDetails odetails = (OrderDetails) obj;
		if (this.orderId == odetails.orderId)
			return true;
		return false;
	}

}
