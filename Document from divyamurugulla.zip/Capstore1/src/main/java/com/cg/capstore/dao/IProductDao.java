package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capstore.entity.Product;

public interface IProductDao extends JpaRepository<Product, Integer>{
	

	/**
	 * @author sumanth
	 * @param productName
	 * @return list of products which matches the given productName
	 */
	List<Product> findByProductName(String productName);
	
	
	/**
	 * @author sumanth
	 * @param productName
	 * @return list of products which matches the given searchKey
	 */
	@Query("select p from Product p where p.productName like concat(lower(:searchkey), '%') or p.productBrand like concat(lower(:searchkey), '%') "  )
	List<Product> searchByName(@Param("searchkey") String searchKey);
	
	@Query("select prod from Product prod left join fetch prod.cat c where c.catId=:cat")
	public List<Product> viewProducts(@Param("cat") int cat);
	
	@Query("select prod from Product prod where prod.isNew=:isnew")
	public List<Product> viewIsNew(@Param("isnew") boolean isNew);
}

