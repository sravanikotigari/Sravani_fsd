package com.cg.capstore.exceptions;

public class LoginException extends Exception{

	public LoginException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	
	}

	public LoginException(String arg0) {
		super(arg0);
		
	}

	
}
