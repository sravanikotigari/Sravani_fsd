package com.cg.capstore.service;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cg.capstore.dao.ICapstoreViewProductDao;
import com.cg.capstore.entity.Product;
import com.cg.capstore.util.CapConstants;

@Service
@Transactional
public class CapstoreImageUploadServiceImpl implements ICapstoreImageUploadService {
	@Autowired
	private ICapstoreViewProductDao prodDao;

	/**
	 * @author Pravallika
	 * @since 27/6/19 This method is used to upload the images into the targeted
	 *        file for the particular product id
	 * @param file - MultipartFile
	 * @param pid - int
	 * @return String
	 */
	@Override
	public String uploadImage(MultipartFile file, int pid) throws IOException {
		String fullName = file.getOriginalFilename();
		String basePath = CapConstants.UPLOAD_IMAGE_PATH;
		String ext = fullName.substring(file.getOriginalFilename().lastIndexOf("."), fullName.length());
		FileOutputStream fos = new FileOutputStream(basePath + pid + ext);
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		byte[] arr = file.getBytes();
		bos.write(arr);
		fos.write(arr);
		bos.close();
		fos.close();
		Product product = prodDao.findById(pid).get();
		product.setImageName(pid + ext);
		prodDao.save(product);
		return "Uploaded Image successfully";

	}
}
