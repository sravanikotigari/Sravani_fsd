  package com.cg.capstore.service;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.dao.RegistrationDao;
import com.cg.capstore.entity.User;
import com.cg.capstore.exceptions.LoginException;

@Service
@Transactional
public class RegistrationServiceImpl implements IRegistartionService {

	@Autowired
	private RegistrationDao registrationDao;

	@Autowired
	private EmailService emailService;
/**
 * @author B.Ranadhher
 * @param user- passing user instance
 * @return newuser on succesfull registration
 */
	@Override
	public User registration(User user) {
		User newUser = registrationDao.save(user);
		String res = emailService.sendEmail(newUser.getEmail(), user.getUserId());
		System.out.println(res);
		return newUser;
	}

	/**
	 * @author Charanjit Singh
	 * @param   user- passing user instance
	 * @return user instance on sucessfull activation 
	 */
	public User turnLoginActive(User user) {
		user.setLoginActive("active");
		return registrationDao.save(user);
	}

	public User findUser(int userId) {
		return registrationDao.findById(userId).get();
	}

	
	/**
	 * @author A.Prithvi RaJ
	 * @param  userid,password
	 * @throws LoginException  when invalid id and password entered
	 * @return  user instance when valid id and password entered
	 */
	@Override
	public User doLogIn(int userId, String pwd) throws LoginException {
		User user = registrationDao.getPwd(userId);
		if (user == null) {
			throw new LoginException("Invalid User Id");
		}
		String decode = new String(Base64.getDecoder().decode(user.getPassword()));
		if (!pwd.equals(decode)) {
			throw new LoginException("Invalid name or password");
		} else if (user.getLoginActive().equalsIgnoreCase("inactive")) {
			throw new LoginException("Your account is not yet activated");
		}
		return user;
	}
      
	/**
	 * @author Y.Abishek
	 * @param  userid,password
	 * @return  user instance when password is changed 
	 */
	@Override
	public User changePwd(int aid, String pwd) throws LoginException {
		User user = registrationDao.findById(aid).get();

		if (user.getPassword().equals(Base64.getEncoder().encodeToString(pwd.getBytes()))) {
			throw new LoginException("Give a new password");
		}
		user.setPassword(Base64.getEncoder().encodeToString(pwd.getBytes()));
		registrationDao.save(user);
		return user;
	}
}
