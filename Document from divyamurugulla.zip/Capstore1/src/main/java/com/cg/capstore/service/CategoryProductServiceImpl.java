package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.dao.ICategoryDao;
import com.cg.capstore.dao.IProductDao;
import com.cg.capstore.dao.IProductSpecificationsDao;
import com.cg.capstore.util.CapConstants;
import com.cg.capstore.entity.Category;
import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.ProductSpecifications;

@Service
@Transactional
public class CategoryProductServiceImpl implements ICategoryProductService {
	
	
	
	@Autowired
	private ICategoryDao cdao;

	@Autowired
	private IProductDao pdao;

	@Autowired
	private IProductSpecificationsDao psdao;

	/**
	 * @author P.Harshini Reddy
	 * @param:  -
	 * @return:list of categories
	 */
	@Override
	public List<Category> viewTopCategories() {
      return cdao.findByParentCategory(CapConstants.TOP_LEVEL_CAT);
	}
	
	
	/**
	 * @author P.Harshini Reddy
	 * @param:   -
	 * @return:List of sub categories for given id
	 */
	@Override
	public List<Category> viewSubCategories(int catId) {
        return cdao.findByParentCategory(catId);
	}
	
	
	/**
	 * @author P.Harshini Reddy
	 * @param  -
	 * @return returns sub categories
	 */
	@Override
	public List<Category> getCategories() {
        return cdao.getCategories();
	}

	
	/**
	 * @author T.Lakshmi Prasanna
	 * @param  cat 
	 * @return  List of products for a given sub category
	 */
	@Override
	public List<Product> viewProducts(int cat) {
       return pdao.viewProducts(cat);
	}

	
	/**
	 * @author B.Soundarya Reddy
	 * @param product
	 * @return adding product details to product table
	 */
	@Override
	public Product addProduct(Product product) {
	    return pdao.save(product);
	}

	
	/**
	 * @author B.Soundarya Reddy
	 * @param productid
	 * @return boolean value true-if product is deleted by id
	 *         boolean value false- if wrong id is entered
	 */
	@Override
	public boolean removeProduct(int productId) {
		pdao.deleteById(productId);
		return true;
	}

	

	/**
	 * @author K.Kranthi
	 * @param productspec
	 * @return adds product specifications to given product id
	 */
	@Override
	public ProductSpecifications addProductSpec(ProductSpecifications productspec) {
        return psdao.save(productspec);

	}

	/**
	 * @author B.Mounika
	 * @param isNew
	 * @return list of newly added products
	 */
	@Override
	public List<Product> newProduct(boolean isNew) {
		return pdao.viewIsNew(isNew);
	}

	
}
