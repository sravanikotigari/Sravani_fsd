package com.cg.capstore.exceptions;

public class IDException extends Exception {

	public IDException(String arg0) {
		super(arg0);
	}
	

}
