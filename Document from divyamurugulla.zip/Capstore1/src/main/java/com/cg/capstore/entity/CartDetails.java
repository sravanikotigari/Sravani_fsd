package com.cg.capstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_cartdetails")
public class CartDetails {

	@Id
	@Column(name = "cart_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartId;

	@Column
	private int status;



	@ManyToOne
	@JoinColumn(name = "user_id", referencedColumnName = "user_id")
	private User user = new User();
	
	@ManyToOne
	@JoinColumn(name = "order_id", referencedColumnName = "order_id")
	private OrderDetails order = new OrderDetails();
	
	@ManyToOne
	@JoinColumn(name = "product_id", referencedColumnName = "product_id")
	private Product product = new Product();
	
	public CartDetails() {

	}

	public CartDetails(int cartId, int status, User user, OrderDetails order, Product product) {
		super();
		this.cartId = cartId;
		this.status = status;
		this.user = user;
		this.order = order;
		this.product = product;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public OrderDetails getOrder() {
		return order;
	}

	public void setOrder(OrderDetails order) {
		this.order = order;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "CartDetails [cartId=" + cartId + ", status=" + status + ", user=" + user + ", order=" + order
				+ ", product=" + product + "]";
	}
	
	

}