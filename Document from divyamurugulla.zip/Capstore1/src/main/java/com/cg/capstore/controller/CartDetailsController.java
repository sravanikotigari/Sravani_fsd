package com.cg.capstore.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.entity.CartDetails;
import com.cg.capstore.entity.OrderDetails;
import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.User;
import com.cg.capstore.service.ICartService;
import com.cg.capstore.util.CapConstants;

@RestController
public class CartDetailsController {

	@Autowired
	private ICartService cartService;

	/**
	 * @author Vidhi
	 * @param userId-int
	 * @param productId-int
	 * @return CartDetails instance
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "addtocart/{userid}/{productid}", method = RequestMethod.GET)
	public CartDetails addToCart(@PathVariable("userid") int userId, @PathVariable("productid") int productId) {
		Product prod = new Product();
		prod.setProductId(productId);
		User user = new User();
		user.setUserId(userId);
		CartDetails cdetails = new CartDetails();
		cdetails.setProduct(prod);
		cdetails.setUser(user);
		cdetails.setOrder(CapConstants.ORDER_EMPTY);
		cdetails.setStatus(CapConstants.ACTIVE);
		return cartService.addToCart(cdetails);

	}

	/**
	 * @author Sushmitha
	 * @param cartId-int
	 * @param userId-int
	 * @return List of CartDetails
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "delete/{cartid}/{userid}", method = RequestMethod.DELETE)
	public List<CartDetails> deleteProductById(@PathVariable("cartid") int cartId, @PathVariable("userid") int userId) {
		cartService.deleteProductById(cartId);
		System.out.println(userId);
		return cartService.viewCartDetails(userId);

	}

	/**
	 * @author Sumedha
	 * @param userId-int
	 * @return List of CartDetails
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "viewall/{userid}", method = RequestMethod.GET)
	public List<CartDetails> viewAllProductsInCart(@PathVariable("userid") int userId) {
		return cartService.viewCartDetails(userId);
	}

	/***
	 * @author Prashanthi
	 * @param orderDetails-OrderDetails
	 *            instance
	 * @param userId-int
	 * @return OrderDetails instance
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "placeorder/{userid}", method = RequestMethod.POST)
	public OrderDetails placeOrderOfProducts(@RequestBody OrderDetails orderDetails,
			@PathVariable("userid") int userId) {
		System.out.println("userID" + userId);
		OrderDetails placedOrder = cartService.placeOrder(orderDetails, userId);
		cartService.updateOrderInCart(placedOrder.getOrderId(), userId);
		return placedOrder;
	}

	/***
	 * @author Shiva
	 * @param userId-int
	 * @return Set of OrderDetails
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "delivery/{userid}", method = RequestMethod.GET)
	public Set<OrderDetails> displayDeliveryStatus(@PathVariable("userid") int userId) {
		return (cartService.viewDeliveryStatus(userId));

	}

	/***
	 * @author Shiva
	 * @param orderId
	 * @return List of products in cart
	 */

	@CrossOrigin("*")
	@RequestMapping(value = "cart/{orderid}", method = RequestMethod.GET)
	public List<CartDetails> displayProductsForOrderID(@PathVariable("orderid") int orderId) {
		return cartService.getProductsForOrderId(orderId);

	}
}
