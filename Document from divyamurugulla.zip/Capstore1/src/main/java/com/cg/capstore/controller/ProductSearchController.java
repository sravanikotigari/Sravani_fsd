package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.entity.Analysis;
import com.cg.capstore.entity.OrderDetails;
import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.User;
import com.cg.capstore.service.IAnalysisSer;
import com.cg.capstore.service.IOrderSer;
import com.cg.capstore.service.IProductSer;
import com.cg.capstore.service.IUserSer;

@CrossOrigin("*")
@RestController
public class ProductSearchController {

	@Autowired
	private IProductSer producetService;

	@Autowired
	private IOrderSer orderService;
	@Autowired
	private IAnalysisSer analysisService;

	@Autowired
	private IUserSer userService;

	/**
	 * @author sowmya
	 * @return list of users
	 */
	@GetMapping(value = "viewall")
	public List<User> viewAll() {

		return userService.viewAll();

	}

	/**
	 * @author sumanth
	 * @param searchKey
	 * @return list of products which matches the given serachKey
	 */
	@GetMapping(value = "search/{searchkey}")
	public List<Product> findAll(@PathVariable("searchkey") String searchKey) {
		return producetService.searchByName(searchKey);

	}

	/**
	 * @author sree devi
	 * @return list of orders
	 */
	@GetMapping(value = "vieworders")
	public List<OrderDetails> viewOrderDetails() {

		return orderService.viewOrders();
	}

	/**
	 * @author rohan raja
	 * @param year
	 * @param pid
	 * @return list of orders and number of products for given productId in a year
	 */
	@GetMapping(value = "analysis/{year}/{pid}")
	public List<Analysis> viewAnalysis(@PathVariable("year") int year, @PathVariable("pid") int pid) {
		return analysisService.viewAnalysis(year, pid);
	}

	/**
	 * @author sree devi
	 * @param lst
	 * @return true if the orders were updated
	 */
	@PostMapping(value = "updateorders")
	public boolean updateOrders(@RequestBody List<OrderDetails> lst) {

		return orderService.updateOrders(lst);
	}

}
