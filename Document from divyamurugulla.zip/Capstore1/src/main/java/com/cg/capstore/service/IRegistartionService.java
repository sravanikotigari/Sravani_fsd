package com.cg.capstore.service;

import com.cg.capstore.entity.User;
import com.cg.capstore.exceptions.LoginException;

public interface IRegistartionService {

	public User registration(User user);
//	public List<User> passwordEncrypto(String pwd);
	public User turnLoginActive(User user);
	public User findUser(int userId);
	
	public User doLogIn(int name, String pwd) throws LoginException;
	public User changePwd(int aid,String pwd) throws LoginException;
	
	
	
}
