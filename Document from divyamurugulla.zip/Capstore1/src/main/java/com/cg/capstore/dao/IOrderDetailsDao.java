package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capstore.entity.CartDetails;
import com.cg.capstore.entity.OrderDetails;
import com.cg.capstore.entity.Product;

public interface IOrderDetailsDao extends JpaRepository<OrderDetails, Integer> {

	

	
}
