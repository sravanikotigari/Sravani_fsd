package com.cg.capstore.service;

public interface IEncryptService {
	public String encodeString(String str);
	public int encodeNumber(int no);

}
