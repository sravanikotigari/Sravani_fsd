package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.entity.User;

public interface IUserSer {	
	List<User> viewAll();
}
