package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.entity.Category;
import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.ProductSpecifications;

public interface ICategoryProductService {

	public List<Category> viewTopCategories();

	public List<Category> viewSubCategories(int catId);

	public List<Category> getCategories();

	public List<Product> viewProducts(int cat);

	public Product addProduct(Product product);

	public boolean removeProduct(int productId);

	/* public boolean updateStock(Product product); */

	public ProductSpecifications addProductSpec(ProductSpecifications productspec);
	
	

	public List<Product> newProduct(boolean isNew);

}
