package com.cg.capstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="capstore_analysis")
public class Analysis {
	
	@Id
	@Column(name="analysis_id")
	private int analysisId;
	
	@Column(name="product_id")
	private int productId;
	
	@Column(name="products_sold")
	private int psold;
	
	
	private int year;
	
	@Column(length=20)
	private String month;
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getPsold() {
		return psold;
	}
	public void setPsold(int psold) {
		this.psold = psold;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	
	
	public int getAnalysisId() {
		return analysisId;
	}
	public void setAnalysisId(int analysisId) {
		this.analysisId = analysisId;
	}
	@Override
	public String toString() {
		return "Analysis [productId=" + productId + ", psold=" + psold + ", year=" + year + ", month=" + month + "]";
	}
	
	

}
