package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.entity.Category;
import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.ProductSpecifications;
import com.cg.capstore.service.ICategoryProductService;

@RestController
public class CategoryProductController {

	@Autowired
	private ICategoryProductService ser;

	/**
	 * @author P.Harshini Reddy
	 * @return list of categories
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "viewcategories", method = RequestMethod.GET)
	public List<Category> viewTopCategories() {
		return ser.viewTopCategories();
	}

	/**
	 * @author P.Harshini Reddy
	 * @return List of sub categories for given id
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "viewsubcats/{catId}", method = RequestMethod.GET)
	public List<Category> viewSubCategories(@PathVariable int catId) {
		return ser.viewSubCategories(catId);

	}

	/**
	 * @author T.Lakshmi Prasanna
	 * @param cat
	 * @return List of products for a given sub category
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "viewproducts/{cat}", method = RequestMethod.GET)
	public List<Product> viewProducts(@PathVariable int cat) {
		return ser.viewProducts(cat);

	}

	/**
	 * @author B.Soundarya Reddy
	 * @param product
	 * @return adding product details to product table
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "addproducts/{catid}", method = RequestMethod.POST)
	public Product addProduct(@RequestBody Product product, @PathVariable("catid") int catId) {
		Category cat = new Category();
		cat.setCatId(catId);
		product.setCat(cat);
		return ser.addProduct(product);

	}

	/**
	 * @author B.Soundarya Reddy
	 * @param productid
	 * @return boolean value true-if product is deleted by id boolean value false-
	 *         if wrong id is entered
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "delete/{productid}", method = RequestMethod.DELETE)
	public String deleteById(@PathVariable("productid") int productId) {
		ser.removeProduct(productId);
		return "Product deleted";
	}

	/**
	 * @author K.Kranthi
	 * @param productspec
	 * @return adds product specifications to given product id
	 */

	@CrossOrigin("*")
	@RequestMapping(value = "addproductspec/{productId}", method = RequestMethod.POST)
	public ProductSpecifications addProductSpec(@RequestBody ProductSpecifications prodspec,
			@PathVariable("productId") int productId) {
		Product prod = new Product();
		prod.setProductId(productId);
		prodspec.setProd(prod);
		return ser.addProductSpec(prodspec);
	}

	/**
	 * @author P.Harshini Reddy
	 * @return returns sub categories
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "getcategories", method = RequestMethod.GET)
	public List<Category> getCategories() {
		return ser.getCategories();

	}

	/**
	 * @author B.Mounika
	 * @param isNew
	 * @return list of newly added products
	 */
	@CrossOrigin("*")
	@RequestMapping(value = "newproducts/{isnew}", method = RequestMethod.GET)
	public List<Product> newProduct(@PathVariable("isnew") boolean isNew) {

		return ser.newProduct(isNew);

	}
}
