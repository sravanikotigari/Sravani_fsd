package com.cg.capstore.controller;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.capstore.entity.Login;
import com.cg.capstore.entity.User;
import com.cg.capstore.exceptions.LoginException;
import com.cg.capstore.service.IEncryptService;
import com.cg.capstore.service.IRegistartionService;

@CrossOrigin("*")

@RestController
public class RegistrationController {
	User user = new User();
	@Autowired
	private IRegistartionService ser;

	@Autowired
	private IEncryptService encService;

	/**
	 * @author B.Ranadheer
	 * @param user
	 * @return String -It returns the Successful message
	 */
	@RequestMapping(value = "register", method = RequestMethod.POST)
	public String registringUser(@RequestBody User user) {
		user.setPassword(Base64.getEncoder().encodeToString(user.getPassword().getBytes()));

		User results = ser.registration(user);

		return "Sucessfully registerd";
	}

	/**
	 * @author Charanjit Singh
	 * @param userId
	 * @return string (activation link)
	 * 
	 */
	@GetMapping(value = "activereg/{userId}")
	public String activateLink(@PathVariable int userId) {
		User user = ser.findUser(userId);
		ser.turnLoginActive(user);
		return "<h1>Your Account is Activated</h1><a href='http://localhost:4200'>Please click here to get into Capstore</a>";
	}

	/**
	 * @author A.Prithvi RaJ
	 * @param user
	 * @return Map
	 * @throws LoginException
	 */
	@RequestMapping(value = "login", method = RequestMethod.POST)
	public Map<String, String> dolog(@RequestBody Login user) throws LoginException {
		User userinstance = ser.doLogIn(user.getUserId(), user.getPassword());
		Login loginInstance = new Login();
		loginInstance.setUserId(encService.encodeNumber(userinstance.getUserId()));
		loginInstance.setUserName(userinstance.getUserName());
		loginInstance.setUserType(encService.encodeString(userinstance.getUserType()));
		// return loginInstance.getUserId()+"@" + loginInstance.getUserName()+"@"+
		// loginInstance.getUserType();
		Map<String, String> map = new HashMap<>();
		map.put("user",
				loginInstance.getUserId() + "=" + loginInstance.getUserName() + "@" + loginInstance.getUserType());
		return map;
	}

	/**
	 * @author Y.Abishek
	 * @param user
	 * @return String
	 * 
	 * 
	 */
	@PostMapping(value = "changepwd")
	public String changePwd(@RequestBody Login user) {
		try {
			ser.changePwd(user.getUserId(), user.getPassword());
		} catch (LoginException e) {
			return e.getMessage();
		}
		return "Successfully changed password";
	}

	/**
	 * @author Y.Abishek
	 * @param user
	 * @return String
	 * 
	 * 
	 */
	@GetMapping(value = "profile/{userid}")
	public User displayProfile(@PathVariable("userid") int userId) {
		User user = ser.findUser(userId);
		user.setPassword("");
		return user;

	}

	@ExceptionHandler
	public Map<String, String> handleException(Exception exception) {
		Map<String, String> map = new HashMap<>();
		map.put("errorMsg", exception.getMessage());
		return map;
	}

}
