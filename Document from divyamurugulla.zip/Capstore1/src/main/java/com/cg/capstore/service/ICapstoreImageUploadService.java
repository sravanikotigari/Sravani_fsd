package com.cg.capstore.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

public interface ICapstoreImageUploadService {
	public String uploadImage(MultipartFile file, int pid) throws IOException;
}
