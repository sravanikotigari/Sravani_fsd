package com.cg.capstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="capstore_category")
public class Category {
	
	@Id
	@Column(name="category_id")
	private int catId;
	
	@Column(name="category_name", length=25)
	private String catName;
	
	@Column(name="parent_cat")
	private int parentCategory;

	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}

	public String getCatName() {
		return catName;
	}

	public void setCatName(String catName) {
		this.catName = catName;
	}

	public int getParentCategory() {
		return parentCategory;
	}

	public void setParentCategory(int parentCategory) {
		this.parentCategory = parentCategory;
	}

	@Override
	public String toString() {
		return "Category [catId=" + catId + ", catName=" + catName + ", parentCategory=" + parentCategory + "]";
	}
	
	

}
