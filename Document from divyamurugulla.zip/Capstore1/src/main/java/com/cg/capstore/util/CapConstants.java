package com.cg.capstore.util;

import com.cg.capstore.entity.OrderDetails;

public interface CapConstants {
   OrderDetails ORDER_EMPTY = null;
   int ACTIVE=1;
   public int TOP_LEVEL_CAT=0;
   String UPLOAD_IMAGE_PATH= "D:\\products_images\\";

}
