package com.cg.capstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="capstore_rating")
public class Rating {
	
	@Id
	@Column(name="rating_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int ratingId;
	
	@Column(name="rating")
	private int rating;
	
	@Column(name="prod_review", length=2000)
	private String prodComment;
	
	@ManyToOne
	@JoinColumn(name="product_id", referencedColumnName="product_id")
	private Product prods;
	
	@ManyToOne
	@JoinColumn(name="user_id", referencedColumnName="user_id")
	private User userId;

	public int getRatingId() {
		return ratingId;
	}

	public void setRatingId(int ratingId) {
		this.ratingId = ratingId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getProdComment() {
		return prodComment;
	}

	public void setProdComment(String prodComment) {
		this.prodComment = prodComment;
	}

	public Product getProds() {
		return prods;
	}

	public void setProds(Product prods) {
		this.prods = prods;
	}

	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Rating [ratingId=" + ratingId + ", rating=" + rating + ", prodComment=" + prodComment + ", prods="
				+ prods + ", userId=" + userId + "]";
	}
	
	

}
