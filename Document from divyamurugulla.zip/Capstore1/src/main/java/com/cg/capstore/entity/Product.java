package com.cg.capstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="capstore_product")
public class Product {

	@Id
	@Column(name="product_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	
	@Column(name="product_name", length=25)
	private String productName;
	
	@Column(name="product_model", length=20)
	private String productModel;
	
	@Column(name="product_brand", length=20)
	private String productBrand;
	
	@Column(name="product_price")
	private double productPrice;
	
	@ManyToOne
	@JoinColumn(name="cat_id", referencedColumnName="category_id")
	private Category cat;
	
	@Column(name="image_name", length=20)
	private String imageName;
	
	@Column(name="product_desc", length=120)
	private String productDesc;
	
	@Column(name="discount_price")
	private double discountPrice;
	
	@Column(name="product_stock")
	private int stock;
	
	@Column(name="is_new")
	private boolean isNew;
	
	@Column(name="promo_discount")
	private int promoDiscount;
	
	@Column(name="promo_code", length=20)
	private String promoCode;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductModel() {
		return productModel;
	}

	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}

	public String getProductBrand() {
		return productBrand;
	}

	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public Category getCat() {
		return cat;
	}

	public void setCat(Category cat) {
		this.cat = cat;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public double getDiscountPrice() {
		return discountPrice;
	}

	public void setDiscountPrice(double discountPrice) {
		this.discountPrice = discountPrice;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	public int getPromoDiscount() {
		return promoDiscount;
	}

	public void setPromoDiscount(int promoDiscount) {
		this.promoDiscount = promoDiscount;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productModel=" + productModel
				+ ", productBrand=" + productBrand + ", productPrice=" + productPrice + ", cat=" + cat + ", imageName="
				+ imageName + ", productDesc=" + productDesc + ", discountPrice=" + discountPrice + ", stock=" + stock
				+ ", isNew=" + isNew + ", promoDiscount=" + promoDiscount + ", promoCode=" + promoCode + "]";
	}

	
	
	
	
}
