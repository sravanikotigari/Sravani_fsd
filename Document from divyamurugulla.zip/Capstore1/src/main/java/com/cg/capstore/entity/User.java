package com.cg.capstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_user")
public class User {

	@Id
	@Column(name = "user_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "userseq")
	@SequenceGenerator(name = "userseq", sequenceName = "userseq1", allocationSize = 1, initialValue = 1000)
	private int userId;

	
	@Column(name = "user_pwd")
	private String password;

	@Column(name = "user_name", length = 25)
	private String userName;

	@Column(name = "user_phone")
	private long phoneNo;

	@Column(name = "user_email", length = 25, unique = true)
	private String email;

	@Column(name = "user_type", length = 20)
	private String userType;
	
	@Column(name="login_active",length=30)
	private String loginActive;


	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

public String getLoginActive() {
		return loginActive;
	}

	public void setLoginActive(String loginActive) {
		this.loginActive = loginActive;
	}

	@Override
	public String toString() {

		return userId + " " + password + " " + userName + " " + phoneNo + " " + email + " " + userType+ " " + loginActive;
	}
}
