package com.cg.capstore.util;

public interface EmailConstants {
	
	String host="smtp.gmail.com";
	String user="govind.corp.trainer@gmail.com";
	String pwd="reshVasi123";
	String port="465";
	String isAuth="true";
	String sslFactory="javax.net.ssl.SSLSocketFactory";

}
