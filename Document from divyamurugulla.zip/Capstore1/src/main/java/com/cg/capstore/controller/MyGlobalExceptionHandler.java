package com.cg.capstore.controller;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.capstore.exceptions.ErrorInfo;
import com.cg.capstore.exceptions.IDException;

@ControllerAdvice
public class MyGlobalExceptionHandler {

	@ExceptionHandler(IDException.class)
	public @ResponseBody ErrorInfo handleException(Exception ex, HttpServletRequest req) {
		String details = req.getRequestURI();
		return new ErrorInfo(LocalDateTime.now(), ex.getMessage(), details);

	}

}
