package com.cg.capstore.service;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.ICartDetailsDao;
import com.cg.capstore.dao.ICustomerProductDao;
import com.cg.capstore.dao.IOrderDetailsDao;
import com.cg.capstore.entity.CartDetails;
import com.cg.capstore.entity.OrderDetails;

@Service("cartDetailsService")
@Transactional
public class CartServiceImpl implements ICartService {

	@Autowired
	private ICartDetailsDao cartDao;

	@Autowired
	private IOrderDetailsDao orderDao;

	@Autowired
	private ICustomerProductDao productDao;

	/**
	 * @author Sushmitha
	 * @param cartId-int
	 * @return true if the product is removed from the cart
	 * @description This method deletes the product from the cart
	 */
	@Override
	public boolean deleteProductById(int cartId) {
		cartDao.deleteById(cartId);
		return true;
	}

	/**
	 * @author Sumedha
	 * @param userId-int
	 * @return List of products in cart for a particular userId
	 * @description This method is used to view the products present in the cart
	 */

	@Override
	public List<CartDetails> viewCartDetails(int userId) {
		return cartDao.viewCartDetails(userId);
	}
	/**
	 * @author Vidhi
	 * @param cart-
	 *            Cart instance
	 * @return Adds/Saves the products in the cart
	 * @description This method adds a particular product in cart
	 */
	@Override
	public CartDetails addToCart(CartDetails cart) {
		return cartDao.save(cart);
	}

	/**
	 * @author Prashanthi
	 * @param orderDetails-
	 *            Order Details instance
	 * @param userId-
	 *            int
	 * @return Placing the order and generating the order ID
	 * @description This method is used to buy the products from the cart
	 */
	@Override
	public OrderDetails placeOrder(OrderDetails orderDetails, int userId) {
		orderDetails.setDate(LocalDate.now());
		orderDetails.setDeliveryStatus("In transit");
		orderDetails.setPaymentMode("COD");

		OrderDetails placedOrder = orderDao.save(orderDetails);
		System.out.println("orderID " + placedOrder.getOrderId());
		return placedOrder;
	}

	/**
	 * @author Prashanthi
	 * @param orderId-int
	 * @param userId-int
	 * @return Updated product stock
	 * @description This method is used to update the stock of the products
	 */

	@Override
	public void updateOrderInCart(int orderId, int userId) {
		cartDao.updateOrderIDInCart(orderId, userId);
		List<CartDetails> lst = cartDao.viewCartDetails(userId);
		for (CartDetails cd : lst) {
			productDao.updateProductStock(cd.getProduct().getProductId());
		}

	}
	/**
	 * @author Shiva
	 * @param userId-int
	 * @return Delivery status of set of orders
	 * @description This method is used to view the delivery status of the ordered
	 *              product
	 */

	@Override
	public Set<OrderDetails> viewDeliveryStatus(int userId) {
		List<CartDetails> lst = cartDao.viewDeliveryStatus(userId);
		Set<OrderDetails> set = new LinkedHashSet<>();
		lst.forEach((kart -> set.add(kart.getOrder())));
		return set;

	}
	/**
	 * @author Shiva
	 * @param orderId-int
	 * @return products for a particular orderId
	 * @description This method is used to display the List of products
	 */
	@Override
	public List<CartDetails> getProductsForOrderId(int orderId){
		return cartDao.getOrderedProducts(orderId);
	}
}
