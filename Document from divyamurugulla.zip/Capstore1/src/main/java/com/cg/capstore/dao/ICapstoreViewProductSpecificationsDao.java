package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capstore.entity.ProductSpecifications;

public interface ICapstoreViewProductSpecificationsDao extends JpaRepository<ProductSpecifications, Integer> {

	/**
	 * @author Rebekah Jacinth
	 * @since 22/6/19
	 * This query is used to get the product specifications for given product
	 * @param pid
	 * @return List
	 */
	@Query("select spec from ProductSpecifications spec left join fetch spec.prod prd where prd.productId=:pid")
	public List<ProductSpecifications> getSpecs(@Param("pid") int pid);
	
}
