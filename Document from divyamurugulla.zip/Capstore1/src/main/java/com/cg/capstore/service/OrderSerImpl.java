package com.cg.capstore.service;

import java.util.List;
import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.dao.IOrderDao;
import com.cg.capstore.entity.OrderDetails;


@Service
@Transactional
public class OrderSerImpl implements IOrderSer{

	@Autowired
	private IOrderDao orderDao;
	
	/**
	 * @author sree devi
	 * @return list of all orders
	 */
	@Override
	public List<OrderDetails> viewOrders() {
	
		return orderDao.viewOrderDetails();
	}

	/**
	 * @author sree devi
	 * @param List<OrderDetails>
	 * @return true if orders were updated
	 */
	@Override
	public boolean updateOrders(List<OrderDetails> lst) {
		
		ListIterator<OrderDetails> iterator = lst.listIterator();
		
		while(iterator.hasNext()) {
			
			OrderDetails order = iterator.next();
			orderDao.save(order);
	      
		}
		
	   return true;	
	}
	
	

}
