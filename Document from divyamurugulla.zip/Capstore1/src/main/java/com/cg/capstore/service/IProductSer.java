package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.entity.Product;

public interface IProductSer {

	List<Product> findByProductName(String productName);
	List<Product> searchByName(String productName);

}
