package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.entity.Analysis;

public interface IAnalysisSer {
List<Analysis> viewAnalysis(int year, int pid);
}
