package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.entity.Category;

public interface ICapstoreViewCategoryDao extends JpaRepository<Category, Integer>{

}
