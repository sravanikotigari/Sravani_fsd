package com.cg.capstore.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.capstore.service.ICapstoreImageUploadService;

@CrossOrigin("*")
@RestController
public class ImageUploadController {

	@Autowired
	private ICapstoreImageUploadService imageService;

	/**
	 * @author Pravallika
	 * @since 27/6/19
	 * @param file
	 * @param pid
	 * @return String
	 * @throws IOException
	 */
	@RequestMapping(value = "upload", method = RequestMethod.POST)
	public String uploadImage(@RequestParam("pfile") MultipartFile file, @RequestParam("pid") int pid)
			throws IOException {

		return imageService.uploadImage(file, pid);

	}
}
