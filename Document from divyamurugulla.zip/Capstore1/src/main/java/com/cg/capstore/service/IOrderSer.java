package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.entity.OrderDetails;

public interface IOrderSer {

	List<OrderDetails> viewOrders();
	 public boolean  updateOrders(List<OrderDetails> lst);	
}
