package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capstore.entity.Product;

public interface ICustomerProductDao extends JpaRepository<Product,Integer> {
	
	@Modifying
	@Query("update Product prod set prod.stock=stock-1 where prod.productId=:prodid")
	int updateProductStock(@Param("prodid") int prodId);
    
}
