package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.capstore.entity.OrderDetails;

public interface IOrderDao extends JpaRepository<OrderDetails, Integer>{

	/**
	 * @author sree devi
	 * @return list of orders which are not delivered
	 */
	@Query("select o from OrderDetails o where o.deliveryStatus not like '%delivered%'")
	List<OrderDetails> viewOrderDetails();
	
}
