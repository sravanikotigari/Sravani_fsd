package com.cg.capstore.service;

import java.util.Arrays;

import org.springframework.stereotype.Service;

@Service
public class EncryptServiceImpl implements IEncryptService{

	@Override
	public String encodeString(String str) {
	    byte[] arr = str.getBytes();
	    System.out.println(Arrays.toString(arr));
	   byte key = 12;
	   StringBuffer buff = new StringBuffer();
	    for(int idx =0; idx< arr.length; ++idx){
	    	System.out.println(arr[idx] -key);
	    	arr[idx] -=  key;
	    	 buff.append(arr[idx]);
	    	 if(idx < arr.length-1)
	    	     buff.append("#");
	    } 
	  
	  
	    
		return buff.toString();
	}

	@Override
	public int encodeNumber(int no) {
		
		return no*7;
	}

	
}
