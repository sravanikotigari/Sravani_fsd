package com.cg.capstore.service;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;
import com.cg.capstore.util.EmailConstants;

@Service
public class EmailService {

	/**
	 * @author M.Ravi Chandra
	 * @param toRecipient 
	 * @param userId
	 * @return
	 */
	public String sendEmail(String toRecipient, int userId) {
		
		String from = EmailConstants.user;
		String host = EmailConstants.host;// or IP address
		String pass = EmailConstants.pwd;
		// Get the session object
		Properties props = System.getProperties();
		
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.socketFactory.port", EmailConstants.port);
		props.put("mail.smtp.socketFactory.class",EmailConstants.sslFactory);
		props.put("mail.smtp.port", EmailConstants.port);
		props.put("mail.smtp.user", from);
		props.put("mail.smtp.password", pass);
		props.put("mail.smtp.auth", EmailConstants.isAuth);
		// Get the default Session object.

		Authenticator auth = new Authenticator() {
			public PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from, pass);
			}
		};

		Session session = Session.getDefaultInstance(props, auth);

		try {
			// Create a default MimeMessage object.
			MimeMessage message = new MimeMessage(session);

			// Set From: header field of the header.
			message.setFrom(new InternetAddress(from));

			// Set To: header field of the header.
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(toRecipient));

			// Set Subject: header field
			message.setSubject("Activation For New Account");

			// Now set the actual message
			String msg = "Please click on the below link<br/>";
			msg+= "User Id: " + userId;
			msg += "<a href='http://localhost:8082/activereg/" + userId+ "'>Click here to activate link</a>";
			message.setContent(msg, "text/html");

			// Send message
			// Transport transport = session.getTransport("smtp");
			/// transport.connect(host, from, pass);
			// transport.sendMessage(message, message.getAllRecipients());
			Transport.send(message);
			return "mail sent successfully";
		} catch (MessagingException mex) {
			mex.printStackTrace();
			return mex.getMessage();
		}
	}
}
