package com.cg.capstore.exceptions;

import java.time.LocalDateTime;

public class ErrorInfo {
	
	
	private LocalDateTime ldt;
	private String errorMessage;
	private String details;
	public ErrorInfo(LocalDateTime ldt, String errorMessage, String details) {
		super();
		this.ldt = ldt;
		this.errorMessage = errorMessage;
		this.details = details;
	}
	public LocalDateTime getLdt() {
		return ldt;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public String getDetails() {
		return details;
	} 


}
