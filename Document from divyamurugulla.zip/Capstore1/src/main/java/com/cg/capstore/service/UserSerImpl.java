package com.cg.capstore.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.IUserDao;
import com.cg.capstore.entity.User;

@Service
@Transactional
public class UserSerImpl implements IUserSer {

	@Autowired
	private IUserDao userDao;
/**
 *@author sowmya
 *@return list of users 
 */
	@Override
	public List<User> viewAll() {

		 List<User> userList= userDao.findAll();
		  userList.forEach(user->{user.setPassword("");});
		 return userList;

	}
}
