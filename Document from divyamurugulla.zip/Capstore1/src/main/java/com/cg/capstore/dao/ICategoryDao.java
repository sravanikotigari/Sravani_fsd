package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.capstore.entity.Category;

public interface ICategoryDao extends JpaRepository<Category, Integer> {
	
	
	public List<Category> findByParentCategory(int parentCategory);
	
	@Query("select cat from Category  cat where parentCategory > 0")
	public List<Category> getCategories();

}
