package com.cg.capstore.service;

import java.util.List;
import java.util.Set;

import com.cg.capstore.entity.CartDetails;
import com.cg.capstore.entity.OrderDetails;

public interface ICartService {

	CartDetails addToCart(CartDetails cart);

	boolean deleteProductById(int cartId);

	List<CartDetails> viewCartDetails(int custId);

	OrderDetails placeOrder(OrderDetails orderDetails, int userId);

	public void updateOrderInCart(int orderId, int userId);

	public Set<OrderDetails> viewDeliveryStatus(int userId);
	
	public List<CartDetails> getProductsForOrderId(int orderId);

}
