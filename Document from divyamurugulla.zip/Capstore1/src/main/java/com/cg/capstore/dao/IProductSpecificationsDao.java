package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.entity.ProductSpecifications;

public interface IProductSpecificationsDao  extends JpaRepository<ProductSpecifications,Integer>  {

}
