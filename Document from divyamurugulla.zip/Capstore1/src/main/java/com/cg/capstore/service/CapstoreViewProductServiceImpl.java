package com.cg.capstore.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.ICapstoreViewCategoryDao;
import com.cg.capstore.dao.ICapstoreViewProductDao;
import com.cg.capstore.dao.ICapstoreViewProductSpecificationsDao;
import com.cg.capstore.dao.ICapstoreViewRatingDao;
import com.cg.capstore.dao.ICapstoreViewUserDao;
import com.cg.capstore.entity.Category;
import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.ProductSpecifications;
import com.cg.capstore.entity.Rating;
import com.cg.capstore.entity.User;
import com.cg.capstore.exceptions.RatingException;

@Service
@Transactional
public class CapstoreViewProductServiceImpl implements ICapstoreViewProductService {

	@Autowired
	private ICapstoreViewProductDao prdDao;

	@Autowired
	private ICapstoreViewProductSpecificationsDao specDao;

	@Autowired
	private ICapstoreViewRatingDao rateDao;

	@Autowired
	private ICapstoreViewUserDao userDao;

	@Autowired
	private ICapstoreViewCategoryDao catDao;

	/**
	 * @author Rebekah Jacinth
	 * @since 22/6/19
	 * This method is used to display the product details
	 * @param productId - int
	 * @return Product instance
	 */
	@Override
	public Product getProduct(int productId) {
		Product prod = prdDao.findById(productId).get();
		return prod;
	}

	/**
	 * @author Rebekah Jacinth
	 * @since 22/6/19
	 * This method is used to display the product specifications
	 * @param productId - int
	 * @return List
	 */
	@Override
	public List<ProductSpecifications> getSpecifications(int productId) {
		return specDao.getSpecs(productId);
	}

	/**
	 * @author Namratha Thakur
	 * @since 25/6/19
	 * This method is used to add the feedback given by the user
	 * @param rating - Rating instance
	 * @param productId - int
	 * @param userId - int
	 * @return Rating instance
	 */
	@Override
	public Rating addRating(Rating rating, int productId, int userId) throws RatingException {
		if (rating.getRating() < 0 || rating.getRating() > 5) {
			throw new RatingException("Rating must be between 0 and 5");
		}
		Product product = getProduct(productId);
		rating.setProds(product);
		User user = getUser(userId);
		rating.setUserId(user);
		rateDao.save(rating);
		return rating;
	}

	/**
	 * @author Akhila Sivaraman
	 * @since 24/6/19
	 * This method is used to display the reviews given by customers
	 * @param productId - int
	 * @return List
	 */
	@Override
	public List<Rating> viewRating(int productId) {
		return rateDao.viewRating(productId);
	}
	
	/**
	 * @author Namratha Thakur
	 * @since  25/6/19
	 * This method is used to get the user id which is used in adding feedback
	 * @param userId - int
	 * @return User instance
	 */
	@Override
	public User getUser(int userId) {
		return userDao.findById(userId).get();
	}
	
	/**
	 * @author Kumari
	 * @since 25/6/19
	 * This method is used to display the similar products for a particular category
	 * @param catId - int
	 * @return List
	 */

	@Override
	public List<Product> similarProducts(int catId) {
		Category cat = catDao.findById(catId).get();
		return prdDao.viewSimilarProducts(cat);
	}
	
	/**
	 * @author Akhila Sivaraman
	 * @since 24/6/19
	 * This method is used to display the average of the ratings given by customers
	 * @param pid - int
	 * @return Float
	 */

	@Override
	public Float averageRating(int pid) {
		Product prod= prdDao.findById(pid).get();
		return rateDao.averageRating(prod);
	}

}
