package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.dao.IAnalysisDao;
import com.cg.capstore.entity.Analysis;
@Service
@Transactional
public class AnalysisSerImpl implements IAnalysisSer{

	@Autowired
	private IAnalysisDao analysisDao;
	/**
	 * @author rohan raja
	 * @param year,pid
	 * @return list of orders for given ProductId in a year
	 */
	@Override
	public List<Analysis> viewAnalysis(int year, int pid) {
	
      return analysisDao.productAnalysis(year, pid);
	}

}
