package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capstore.entity.User;

public interface RegistrationDao  extends JpaRepository<User,Integer>{
  
	
	
	/**
	 * @author A.Prithvi RaJ
	 * @param userId
	 * @param passwd
	 * @return user instance for particular given id and password from database
	 */
	@Query("From User where userId=:userid and password=:pwd")
	public  User logIn(@Param("userid") int userId, @Param("pwd") String passwd);
	
	
	/**
	 * @author Abishek
	 * @param userId
	 * @return  user instance for particular given id  from database
	 */
	@Query("From User where userId=:uid")
	public User getPwd(@Param("uid")int userId);
	
	
}