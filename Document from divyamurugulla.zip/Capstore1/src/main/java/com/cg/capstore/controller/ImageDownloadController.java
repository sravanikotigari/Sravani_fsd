package com.cg.capstore.controller;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin("*")
@RestController
public class ImageDownloadController {

	@RequestMapping(value = "image/{imgname}")
	public void displayImage(@PathVariable("imgname") String imgName, HttpServletResponse resp) throws IOException {
		resp.setContentType("image/jpeg");
		FileInputStream fis = new FileInputStream("d:\\products_images\\" + imgName);
		BufferedInputStream bis = new BufferedInputStream(fis);
		ServletOutputStream os = resp.getOutputStream();
		byte[] binary = new byte[(int) fis.available()];
		bis.read(binary);
		os.write(binary);
		os.flush();

	}
}
