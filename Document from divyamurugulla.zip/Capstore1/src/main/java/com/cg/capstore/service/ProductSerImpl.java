package com.cg.capstore.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.IProductDao;
import com.cg.capstore.entity.Product;

@Service
@Transactional
public class ProductSerImpl implements IProductSer{
	
	@Autowired IProductDao productDao;


    /**
     * @author sumanth
     * @param productName
     * @return list of products which matches the given productName
     */
	@Override
	public List<Product> findByProductName(String productName) {
		return productDao.findByProductName(productName);
	}

	/**
	 * @author sumanth
     * @param productName
     * @return list of products which matches the given productName* 
	 */
	@Override
	public List<Product> searchByName(String searchKey) {
		
		return productDao.searchByName(searchKey);
	}

	
	

	
}


