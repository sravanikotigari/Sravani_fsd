package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capstore.entity.Category;
import com.cg.capstore.entity.Product;

public interface ICapstoreViewProductDao extends JpaRepository<Product, Integer> {

	/**
	 * @author Kumari
	 * @since 25/6/19
	 * This query is used to get the similar products of a particular category
	 * @param cat
	 * @return List
	 */
	@Query("select prod from Product prod where prod.cat=:cid")
	List<Product> viewSimilarProducts(@Param("cid") Category cat);
	
}
