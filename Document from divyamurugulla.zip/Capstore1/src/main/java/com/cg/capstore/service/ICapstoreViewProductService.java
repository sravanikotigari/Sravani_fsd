package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.ProductSpecifications;
import com.cg.capstore.entity.Rating;
import com.cg.capstore.entity.User;
import com.cg.capstore.exceptions.RatingException;

public interface ICapstoreViewProductService {
	
	public Product getProduct(int productId);
	
	public List<ProductSpecifications> getSpecifications(int productId);
	
	public Rating addRating(Rating rating, int productId, int userId) throws RatingException;
	
	public List<Rating> viewRating(int prouctId);

	public User getUser(int userId);
	
	public List<Product> similarProducts(int catId);
	
	
	public Float averageRating(int pid);
	
}
