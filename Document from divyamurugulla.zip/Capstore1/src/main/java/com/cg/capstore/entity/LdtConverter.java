package com.cg.capstore.entity;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
@Converter(autoApply=true)
public class LdtConverter implements AttributeConverter<LocalDate,Date> {

	@Override
	//LocalDate is converted into java.sql.date
	public Date convertToDatabaseColumn(LocalDate ldt) {
		
		return Date.valueOf(ldt);
	}

	@Override
	//java.sql.date converted into localdate
	public LocalDate convertToEntityAttribute(Date sqldt) {
		
		return sqldt.toLocalDate();
	}

	
	
	
}
