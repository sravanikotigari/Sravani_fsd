package com.cg.capstore.exceptions;

public class RatingException extends Exception {

	public RatingException(String message) {
		super(message);
		}

}
