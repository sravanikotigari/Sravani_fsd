package com.cts.springbootjpa.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.springbootjpa.entity.TransactionHistory;

public interface TransactionDao extends JpaRepository<TransactionHistory, Integer>{

}
