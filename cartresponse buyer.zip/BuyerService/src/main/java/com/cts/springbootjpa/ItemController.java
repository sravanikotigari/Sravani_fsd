package com.cts.springbootjpa;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.springbootjpa.entity.CartItems;
import com.cts.springbootjpa.entity.CartResponse;
import com.cts.springbootjpa.entity.TransactionHistory;
import com.cts.springbootjpa.service.Iservice;


@CrossOrigin("*")
@RestController
public class ItemController {
	
	@Autowired
	private Iservice service;
	
	
	
	
	@RequestMapping("/getAll/items") 
	public List<CartItems> getAllItems() 
    {
		  return service.getAllItems(); 
    }
	@RequestMapping(value="/Add/items/{ids}",method=RequestMethod.POST)
	public CartItems add(@RequestBody CartItems cartitems,@PathVariable("ids") int id) 
	{
		return service.addcart(cartitems,id);
	}
	@RequestMapping(value="/getItem/{ids}",method=RequestMethod.GET)
	public CartItems getItem(@PathVariable("ids") int id) 
	{
		return service.getItem(id);
	}
//	@RequestMapping(value="/update/items/{ids}",method=RequestMethod.PUT)
//	public CartItems updateItem(@RequestBody CartItems cartitems,@PathVariable("ids") int id) 
//	{
//		return service.updateItem(cartitems,id);
//	}
	@PutMapping(value="/updatecart",produces="application/json")
	public CartResponse updateCart(@RequestBody CartResponse cartresponse)
	{
		return service.updateItem(cartresponse);
	}
	
	@RequestMapping(value="/DeleteItem/{ids}",method=RequestMethod.DELETE)
	public void deleteItem(@PathVariable("ids") int id) 
	{
		 service.deleteItem(id);
	}
	@RequestMapping(value="/DeleteAllItem",method=RequestMethod.DELETE)
	public void deleteAllItem() 
	{
		 service.deleteAllItem();
	}	
	
	@PostMapping("/checkout/{ids}") 
	public String checkout(@RequestBody TransactionHistory transactionhistory,@PathVariable("ids") int id) 
	{
		return service.checkout(transactionhistory,id);
	}
	
	
	

}
