package com.cts.buyer.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.buyer.entity.PurchaseHistory;
import com.cts.buyer.repository.IPurchaseHistory;

@Service
public class PurchaseHistoryService {
	
	@Autowired
	private IPurchaseHistory iPurchaseHistory;
	
	@Autowired
	private TransactionService transactionService;
	
	public PurchaseHistory addPurchaseHistory(PurchaseHistory purchaseHistory){
		return iPurchaseHistory.save(purchaseHistory);
	}
}
