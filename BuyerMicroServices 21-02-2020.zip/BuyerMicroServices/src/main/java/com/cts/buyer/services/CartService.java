package com.cts.buyer.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.entity.CartItems;
import com.cts.buyer.entity.Item;
import com.cts.buyer.entity.PurchaseHistory;
import com.cts.buyer.entity.TransactionHistory;
import com.cts.buyer.repository.IBuyerRepository;
import com.cts.buyer.repository.ICartRepository;
import com.cts.buyer.repository.ITransactionHistory;

@Service
public class CartService {
	
	@Autowired
	private ICartRepository cartRepository;
	
	@Autowired
	private IBuyerRepository buyerRepository;
	
	@Autowired
	private TransactionService transactionHistoryServices;
	
	@Autowired
	private PurchaseHistoryService purchaseHistoryServices;
	
	public Optional<CartItems> addItemToCart(CartItems cartItem, Integer buyerId) {
		return buyerRepository.findById(buyerId).map(buyer -> {
            cartItem.setBuyer(buyer);
            return cartRepository.save(cartItem);
        });
	}
	
	public String deleteCartItem(Integer cartItemId) {
		cartRepository.deleteById(cartItemId);
		return "Deleted";
	}
	
	public String emptyCartItems(Integer buyerId) {
		cartRepository.deleteBybuyer(buyerId);
		return "deleted";
	}
	
	
	 public List<CartItems> getallCartItems(Integer buyerId){ 
		 List<CartItems>items = cartRepository.findAllBybuyer(buyerId); 
		 return items; 
	}
	
	public CartItems updateCartItem(CartItems item, Integer cartItemId) {
		Optional<CartItems> cartItem = cartRepository.findById(cartItemId);
		if(cartItem.isPresent()) {
			CartItems newCartItem = cartItem.get();
			newCartItem.setQuantity(item.getQuantity());
			return cartRepository.save(newCartItem);
		}
		return null;
	}
	
	public void checkout(CartItems cartItem, PurchaseHistory purchaseHistory, TransactionHistory transactionHistory, Integer buyerId) {
		transactionHistoryServices.addTransaction(transactionHistory, buyerId);
		Optional<BuyerInfo> buyer = buyerRepository.findById(buyerId);
		purchaseHistory.setBuyer(buyer.get());
		purchaseHistory.setTransaction(transactionHistory);
		PurchaseHistory purchaseHistoryAfterAdding = purchaseHistoryServices.addPurchaseHistory(purchaseHistory);
	}
}
