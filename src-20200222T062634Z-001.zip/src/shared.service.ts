import { Injectable } from '@angular/core';
import { Cart } from './app/cart';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
cart : Cart;
productId : number;

  constructor() { }

  getCart()
  {
    return this.cart;
  }
  setCart($cart : Cart)
  {
    this.cart = $cart;
  }

  getProduct() : number
  {
    return this.productId;
  }
  setProduct($product : number) :void
  {
    this.productId = $product;
  }

}
