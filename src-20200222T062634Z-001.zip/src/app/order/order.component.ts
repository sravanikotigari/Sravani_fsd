import { Component, OnInit } from '@angular/core';
import { Cart } from '../cart';
import { CapstoreserviceService } from '../capstoreservice.service';
import { Router } from '@angular/router';
import { OrderBean } from '../order';
import { SharedService } from 'src/shared.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  constructor(private service :CapstoreserviceService, private route : Router,private data : SharedService) { }

  ngOnInit() {
  }

message:string;
order : OrderBean ;
items : Cart;
addr = this.data.getCart();
placeOrderAfterCheckout()
{

  this.items = this.data.getCart();
  this.service.placeOrder(this.items).subscribe(resp=>
    {
      if(resp['errorMessage']!=undefined)
    {
      this.message=resp['errorMessage'];
    }
    else
    {
     this.message=resp;
     alert(this.message);
    //  this.data.setProduct(this.order.cart.product.productId);
     this.route.navigate(["/viewallorders"]);
    }
    }
    );

}

}
