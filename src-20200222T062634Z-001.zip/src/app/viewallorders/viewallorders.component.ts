import { Component, OnInit } from '@angular/core';
import { OrderBean } from '../order';
import { CapstoreserviceService } from '../capstoreservice.service';
import { SharedService } from 'src/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewallorders',
  templateUrl: './viewallorders.component.html',
  styleUrls: ['./viewallorders.component.css']
})
export class ViewallordersComponent implements OnInit {
  userId = sessionStorage.getItem("userid");
  message : any;
  orders : OrderBean[];
  status = false;

  constructor(private service :CapstoreserviceService, private route : Router ,private share : SharedService) { }

  ngOnInit() {
    this.service.viewOrdersByUserId(this.userId).subscribe(resp=>
      { 
        this.orders=resp;
      if(this.orders.length<=0)
      {
        this.status=true;
      }
    } );
    
  }

  delete(order : OrderBean )
{
  this.service.deleteOrder(order.orderId).subscribe(resp=> {
    if(resp['errorMessage']!=undefined)
  {
    this.message=resp['errorMessage'];
  }
  else
  {
   this.message=resp;
  //  alert(this.message);
   this.orders = this.orders.filter(p=>p.orderId!=order.orderId)
  }
  });
}

submitProductFeedback(productNo : number)
{
  //console.log(product);
  this.share.setProduct(productNo);
  this.route.navigate(["givefeedback"]);

}



}
