import { Product } from './product';
import { UserProfile } from './userprofile';

export class Cart
{
    cartId : number;
    customerDetails : UserProfile;
    product : Product;
    productQuantity : number;
    productCost : number;
    

}