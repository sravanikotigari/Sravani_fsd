import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homecustomer',
  templateUrl: './homecustomer.component.html',
  styleUrls: ['./homecustomer.component.css']
})
export class HomecustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
