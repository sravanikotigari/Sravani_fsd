import { Component, OnInit } from '@angular/core';
import { CapstoreserviceService } from '../capstoreservice.service';
import { Product } from '../product';

@Component({
  selector: 'app-viewproduct',
  templateUrl: './viewproduct.component.html',
  styleUrls: ['./viewproduct.component.css']
})
export class ViewproductComponent implements OnInit {

  product:Product=new Product();
  productId:number;
  message:any;
  status=false;
  display=false;
  constructor(private service:CapstoreserviceService) { }

  ngOnInit() {
  }
  show()
{
  this.service.findProduct(this.productId).subscribe(resp=>
    {
     
      if(resp['errorMessage']!=undefined)
      {
       
      this.status=true;
     
      this.display=false;
      this.message=resp['errorMessage'];
      
      }
      else
      {
        this.status=false;
        this.display=true;
        this.product=resp;
        // this.message="Product Details are.."
      
      }
    });

}


}
