import { Component, OnInit } from '@angular/core';
import { Product } from '../Product';

import { CapstoreserviceService } from '../capstoreservice.service';

@Component({
  selector: 'app-searchproduct',
  templateUrl: './searchproduct.component.html',
  styleUrls: ['./searchproduct.component.css']
})
export class SearchproductComponent implements OnInit {
  value = false;
  Array1: Product[] = [];
  Array2: Product[] = [];
  message: any;
  status = false;
  display = false;
  show = false;
  products: Product[] = [];
  constructor(private service: CapstoreserviceService) { }

  ngOnInit() {
    this.service.listAllProducts().subscribe(resp => {

      if (resp['errorMessage'] != undefined) {
        this.status = true;
        this.display=false;
        this.message = resp['errorMessage'];
      }
      else {
        this.status=false;
        this.display = true;
        this.products = resp;
      }
    });

  }

  filter(input: string) {
    let Array1 = this.products.filter((item) => (item.productName.toLowerCase() ==input.toLowerCase())
      || (item.productCategory.toLowerCase() == input.toLowerCase()) || item.productName.toLowerCase().startsWith(input.toLowerCase())
      || (item.productCategory.toLowerCase().startsWith(input.toLowerCase())));
    this.Array2 = Array1;
    this.status=false;
    if (this.Array2.length == 0) {
      this.status = true;
      this.value = false;
      this.message = "NO PRODUCTS FOUND!"
    }
    this.value = true;

  }
}



