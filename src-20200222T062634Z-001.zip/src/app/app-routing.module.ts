import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderComponent } from './order/order.component';
import { ViewallordersComponent } from './viewallorders/viewallorders.component';
import { ViewallproductsincartComponent } from './viewallproductsincart/viewallproductsincart.component';
import { UpdateloginComponent } from './updatelogin/updatelogin.component';
import { LogoutComponent } from './logout/logout.component';
import { LoginComponent } from './login/login.component';
import { MerchantComponent } from './merchant/merchant.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { ListallproductComponent } from './listallproduct/listallproduct.component';
import { ViewproductComponent } from './viewproduct/viewproduct.component';
import { SearchproductComponent } from './searchproduct/searchproduct.component';
import { ViewprofileComponent } from './viewprofile/viewprofile.component';
import { SearchComponent } from './search/search.component';
import { ViewcustomerComponent } from './viewcustomer/viewcustomer.component';
import { CheaderComponent } from './cheader/cheader.component';
import { HomecustomerComponent } from './homecustomer/homecustomer.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { ViewcustomerproductComponent } from './viewcustomerproduct/viewcustomerproduct.component';
import { AdminComponent } from './admin/admin.component';
import { ProductDetailsComponent } from './admin/product-details/product-details.component';
import { MerchantDetailsComponent } from './admin/merchant-details/merchant-details.component';
import { AddComponent } from './admin/add/add.component';
import { CustomerDetailsComponent } from './admin/customer-details/customer-details.component';
import { SignupComponent } from './signup/signup.component';
import { LoginGuard } from './login.guard';
import { GivefeedbackComponent } from './givefeedback/givefeedback.component';

const routes: Routes = [
  { path : '', redirectTo : '/login' , pathMatch : 'full'},
  {path : 'order' , component:OrderComponent},
  {path:'login',component:LoginComponent},
  {path : 'viewallproductsincart', component:ViewallproductsincartComponent},
  {path:'viewallorders', component: ViewallordersComponent},
  {path:'logout',component:LogoutComponent},
  {path:'updatelogin',component:UpdateloginComponent},
  {path:'merchant',canActivate:[LoginGuard],component:MerchantComponent,data:{"role":"Merchant"}},
  {path:'addmerchant',component:SignupComponent},
  {path:'addProduct',canActivate:[LoginGuard],component:AddproductComponent,data:{"role":"Merchant"}},
  {path:'listallproducts',canActivate:[LoginGuard],component:ListallproductComponent,data:{"role":"Merchant"}},
  {path:'viewproduct',canActivate:[LoginGuard],component:ViewproductComponent,data:{"role":"Merchant"}},
  {path:'searchproduct',component:SearchproductComponent},
  {path :'viewmerchantprofile', component : ViewprofileComponent},
  {path:'search',canActivate:[LoginGuard],component:SearchComponent,data:{"role":"Customer"}},
  {path:'viewcustomer',canActivate:[LoginGuard],component:ViewcustomerComponent,data:{"role":"Customer"}},
  {path:'customer',canActivate:[LoginGuard],component:HomecustomerComponent,data:{"role":"Customer"}},
  {path:'createcustomer',component:CreateaccountComponent},
  {path:'home',component:HomecustomerComponent},
  {path:'productdetails',canActivate:[LoginGuard],component:ViewcustomerproductComponent,data:{"role":"Customer"}},
  {path:'cheader',component:CheaderComponent},
  {path:'admin',canActivate:[LoginGuard],component:AdminComponent,data:{"role":"Admin"}},
  {path:'admin/productdetails',component:ProductDetailsComponent,data:{"role":"Admin"}},
  {path:'admin/merchantdetails',component:MerchantDetailsComponent,data:{"role":"Admin"}},
  {path:'admin/adduser',component:AddComponent,data:{"role":"Admin"}},
  {path:'admin/customerdetails',component:CustomerDetailsComponent,data:{"role":"Admin"}},
  {path :'givefeedback',component : GivefeedbackComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
