import { Component, OnInit } from '@angular/core';
import { Feedback } from '../feedback';
import { SharedService } from 'src/shared.service';
import { CapstoreserviceService } from '../capstoreservice.service';
import { Product } from '../product';
import { OrderBean } from '../order';
import { Cart } from '../cart';

@Component({
  selector: 'app-givefeedback',
  templateUrl: './givefeedback.component.html',
  styleUrls: ['./givefeedback.component.css']
})
export class GivefeedbackComponent implements OnInit {

 
  feedback : Feedback = new Feedback();
  constructor(private service : CapstoreserviceService, private share : SharedService) { 
     this.feedback.productId = new Product();
  }
  productNo:number;
  product : Product;
  orders : OrderBean = new OrderBean();
  cart : Cart = new Cart();
  status=false;
  message:string;


  ngOnInit() {
   this.productNo =this.share.getProduct();

    }

  giveFeedback()
  {

  
   this.status=true;
     console.log(this.feedback); 
    this.feedback.productId.productId= this.productNo;
    this.service.giveFeedback(this.feedback,this.productNo).subscribe(resp=>{
           this.message=resp;
      
        alert(this.message);
        window.location.href="viewallorders";
    })
  }


}
