import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OrderComponent } from './order/order.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ViewallordersComponent } from './viewallorders/viewallorders.component';
import {HttpClientModule} from '@angular/common/http';
import { AddproducttocartComponent } from './addproducttocart/addproducttocart.component';
import { ViewallproductsincartComponent } from './viewallproductsincart/viewallproductsincart.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { UpdateloginComponent } from './updatelogin/updatelogin.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { DeleteproductComponent } from './deleteproduct/deleteproduct.component';
import { ListallproductComponent } from './listallproduct/listallproduct.component';
import { MerchantComponent } from './merchant/merchant.component';
import { SearchproductComponent } from './searchproduct/searchproduct.component';
import { UpdateComponent } from './update/update.component';
import { UpdateproductComponent } from './updateproduct/updateproduct.component';
import { ViewproductComponent } from './viewproduct/viewproduct.component';
import { ViewprofileComponent } from './viewprofile/viewprofile.component';
import { HeaderComponent } from './header/header.component';
import { CheaderComponent } from './cheader/cheader.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { HomecustomerComponent } from './homecustomer/homecustomer.component';
import { SearchComponent } from './search/search.component';
import { ViewcustomerComponent } from './viewcustomer/viewcustomer.component';
import { ViewcustomerproductComponent } from './viewcustomerproduct/viewcustomerproduct.component';
import { AdminComponent } from './admin/admin.component';
import { CustomerDetailsComponent } from './admin/customer-details/customer-details.component';
import { ProductDetailsComponent } from './admin/product-details/product-details.component';
import { MerchantDetailsComponent } from './admin/merchant-details/merchant-details.component';
import { AddComponent } from './admin/add/add.component';
import { SignupComponent } from './signup/signup.component';
import { GivefeedbackComponent } from './givefeedback/givefeedback.component';


@NgModule({
  declarations: [
    AppComponent,
    OrderComponent,
    ViewallordersComponent,
    AddproducttocartComponent,
    ViewallproductsincartComponent,
    LoginComponent,
    LogoutComponent,
    UpdateloginComponent,
    AddproductComponent,
    DeleteproductComponent,
    ListallproductComponent,
    MerchantComponent,
    SearchproductComponent,
    UpdateComponent,
    UpdateproductComponent,
    ViewproductComponent,
    ViewprofileComponent,
    HeaderComponent,
    CheaderComponent,
    CreateaccountComponent,
    HomecustomerComponent,
    SearchComponent,
    ViewcustomerComponent,
    ViewcustomerproductComponent,
    AdminComponent,
    CustomerDetailsComponent,
    ProductDetailsComponent,
    MerchantDetailsComponent,
    AddComponent,
    SignupComponent,
    GivefeedbackComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
