import { Component, OnInit } from '@angular/core';
import { CapstoreserviceService } from '../capstoreservice.service';
import { Product } from '../product';
import { SharedService } from 'src/shared.service';
import { Feedback } from '../feedback';
import { Cart } from '../cart';

@Component({
  selector: 'app-viewcustomerproduct',
  templateUrl: './viewcustomerproduct.component.html',
  styleUrls: ['./viewcustomerproduct.component.css']
})
export class ViewcustomerproductComponent implements OnInit {

 
  productId : number;
  
  flag = false;
  status = false;
  message : string;
  products : Product;
  feedbacks : Feedback[];
  discount : number;
  discountPrice:number;
  userName : string;
  cart:Cart;
  userId = sessionStorage.getItem("userid");

  constructor(private service : CapstoreserviceService,
    private data : SharedService) { }

  ngOnInit() {
   this.products = new Product();

  
    this.status=true;
    this.productId = this.data.getProduct();
    this.service.viewProduct(this.productId).subscribe(
      (data:Product) => {
        
          
          
          this.flag=true;
          this.products=data;
          this.discount = this.products.productDiscount; 
          
          this.discount=(((this.products.productDiscount)/100)*this.products.productPrice);
          this.discountPrice=(this.products.productPrice-this.discount);
        
    });

    this.service.viewFeedback(this.productId).subscribe(
     (data:Feedback[]) => {
         this.status=true;
        this.feedbacks=data;
        if(this.feedbacks.length==null) {
          console.log(this.feedbacks);
          this.status=false;
        } 
        
    });
 
  }

  

  addProductToCart()
  {
    this.service.addProductToCart(this.userId,this.discountPrice,this.products).subscribe(response=>
      {
        if(response['errorMessage']!=undefined)
      {
        this.message=response['errorMessage'];
      }
      else
      {
       this.message=response;
      }
      }
      );
  }



}
