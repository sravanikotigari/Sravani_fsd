import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-cheader',
  templateUrl: './cheader.component.html',
  styleUrls: ['./cheader.component.css']
})
export class CheaderComponent implements OnInit {

  url : string;
  constructor(
    private router : Router
  ) { }

  ngOnInit() {
    this.router.events.
    subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.url = event.url;
      }
    });
  }
  loginCheck():boolean
  {
    if(this.url=='/login')
    return true;
  }

}
