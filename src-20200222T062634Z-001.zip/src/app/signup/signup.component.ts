import { Component, OnInit } from '@angular/core';
import { CapstoreserviceService } from '../capstoreservice.service';
import { UserProfile } from '../userprofile';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  userprofile : UserProfile= new UserProfile();
  password : String;
  confirmPassword : String;
  message : any;
  status = false;

  constructor(private service : CapstoreserviceService) { }

  ngOnInit() {
    
    }
   signup()
   {
    this.status=true;
    this.service.signUpMerchant(this.userprofile,this.password).subscribe(resp=>{
    this.message=resp;
   });
  }
}

 


