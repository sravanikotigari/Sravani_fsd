import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { Router } from '@angular/router';
import { CapstoreserviceService } from '../capstoreservice.service';
import { SharedService } from 'src/shared.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  trigger: boolean = false;
  keyword: string;
  notfound: boolean = false;
  public categories: Array<string>;
  private product: Product[];
  category: string = 'All Categories';
  constructor(
    private service: CapstoreserviceService,
    private data : SharedService,
    private router : Router
  ) { }

  ngOnInit() {
    this.categories =
      [
        'All Categories',
        'Electronics',
        'Household',
        'Clothing',
        'Luggage',
        'Books',
        'Sports',
        'Accessories'
      ]
  }
  search() {
    if (this.category != 'All Categories') {
      this.service.getProductsByCategory(this.category, this.keyword).subscribe(
        (data) => {
          this.product = data as Product[];
          if (this.product.length == 0) {
            this.notfound = true;
          }
          else {
            this.trigger = true;
            this.notfound = false;
          }
        },
        (error) => {
          console.log(error.message);
        }
      )

    }
    else {
      this.service.getproductlist(this.keyword).subscribe(
        (data) => {
          this.product = data as Product[];
          if (this.product.length == 0) {
            this.notfound = true;
          }
          else {
            this.trigger = true;
            this.notfound = false;
          }
        },
        (error) => {
          console.log(error.message);
        }
      )

    }

  }
  view($product : number)
  {
this.data.setProduct($product);
this.router.navigate(['productdetails'])
  }


}
