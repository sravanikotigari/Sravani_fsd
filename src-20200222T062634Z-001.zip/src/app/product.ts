import { UserProfile } from './userprofile';

export class Product 
{

    productId : number;
    productName : string;
    productPrice : number;
    productCategory : string;
    productDescription : string ;
    productImage : string;
    productDiscount : number;
    merchantDetails : UserProfile = new UserProfile(); 
}