import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { OrderBean } from './order';
import { Observable } from 'rxjs';
import { CapstoreWebURL } from './capstoreweburl';
import { Cart } from './cart';
import { Product } from './product';
import { UserProfile } from './userprofile';
import { Login } from './login';
import { Feedback } from './feedback';

@Injectable({
  providedIn: 'root'
})
export class CapstoreserviceService {

  constructor(private http: HttpClient) { }


  public viewOrdersByUserId(userId: String) : Observable<any>
  {
    return this.http.get(CapstoreWebURL.URL+"/order/viewAllOrders/"+userId);
  }

  public placeOrder(order: Cart) : Observable<any>
  {
    console.log(order);
    return this.http.post(CapstoreWebURL.URL+"/order/placeOrder/",order,{ responseType : 'text'});
  }

  public deleteOrder(orderId: number) : Observable<any>
  {
    return this.http.delete(CapstoreWebURL.URL+"/order/deleteOrder/"+orderId,{ responseType : 'text'});
  }

  public viewAllProductInCart(userId :String ) :Observable<any>
  {
    return this.http.get(CapstoreWebURL.URL+"/cart/viewAllProductInCart/"+userId);
  }

  public updateProductQuantityInCart(cartID: number, quantity: number): Observable<any>
  {
    return this.http.put(CapstoreWebURL.URL+"/cart/updateCart/"+cartID+"/"+quantity, null, { responseType: "text" });

  }

  public deleteProduct(productId: number,userId:string) : Observable<any>
  {
    return this.http.delete(CapstoreWebURL.URL+"/cart/deleteProductFromCart/"+productId+"/"+userId,{responseType :'text'});
  }

  validateLogin(userId:string,userPassword:string,userType:string):Observable<any>

  {
    return this.http.get( CapstoreWebURL.URL+"/login/login/"+userId+"/"+userPassword+"/"+userType,{responseType: 'text' as 'json'})
  }
  
  updateLogin(userId:string, newPassword:string):Observable<any>
  {
  
  console.log(newPassword);
    return this.http.put( CapstoreWebURL.URL+"/login/updatelogin/"+userId+"/"+newPassword,null,{responseType:'text'});
  }
  
  public isLoogedIn():boolean{
    return (sessionStorage.getItem("user") !== null);
  }
  
   
  logout() {
   sessionStorage.removeItem("user");
   
  }

  public addProduct(product:Product):Observable<any>
  {
    return this.http.post( CapstoreWebURL.URL+"/merchant/addProduct",product);
  }

  public listAllProducts():Observable<any>
  {
    return this.http.get("http://localhost:9090/merchant/listproduct");
  }

  public listAllProductsById(id:string):Observable<any>
  {
    return this.http.get("http://localhost:9090/merchant/listproductById/"+id);
  }

  public DeleteProduct(productId:Number):Observable<any>
  {
    return this.http.delete("http://localhost:9090/merchant/deleteProduct/"+productId,{responseType:'text'});
  }

  public updateProduct(product:any):Observable<any>
  {
    return this.http.put("http://localhost:9090/merchant/updateproduct",product);
  }

  public findProduct(id:Number):Observable<any>
  {
    return this.http.get("http://localhost:9090/merchant/findproduct/"+id);
  }

  public viewMerchantprofile(userid : string) : Observable<any>
  {
    return this.http.get("http://localhost:9090/merchant/viewMerchantProfile/"+userid)
  }


  public updateMerchantProfile(userProfile:UserProfile):Observable<any>
  {
    return this.http.put("http://localhost:9090/merchant/updateMerchantProfile",userProfile);
  }

  getproductlist(searchKeyword : string):Observable<any>
  {
      return this.http.get(`http://localhost:9090/customer/similar/${searchKeyword}`);
  }
  getProductsByCategory(category:string,searchKeyword:string):Observable<any>
  {
    return this.http.get(`http://localhost:9090/customer/search/${category}/${searchKeyword}`);
  }

  public getCustomerDetails(customerId:string) :Observable<any>{

    return this.http.get("http://localhost:9090/customer/viewcustomer/"+customerId);
}  
public updateUserDetails(customerId:string,customerDetails:UserProfile) :Observable<any>{

  return this.http.put("http://localhost:9090/customer/updatecustomer/"+customerId,customerDetails,{responseType:'text'});
}
public createcustomerProfile(customerDetails:UserProfile,customerPassword:string) :Observable<any>
{
  return this.http.post("http://localhost:9090/customer/addcustomer/"+customerPassword,customerDetails,{responseType :'text'});
}  

public viewProduct(productId : number) : Observable<any> {
  return this.http.get("http://localhost:9090/customer/productdetails/"+productId);  
}
public viewFeedback(productId : number) : Observable<any> {
  return this.http.get("http://localhost:9090/customer/feedbackdetails/"+productId);
}
public addProductToCart(userId:string,discountPrice:number,product:Product ) :Observable<any>
{
  return this.http.post("http://localhost:9090/cart/addProductToCart/"+userId+"/"+discountPrice,product,{responseType:'text'});
}

viewusers(userType:string):Observable<any>
{
  return this.http.get(`http://localhost:9090/admin/viewallusers/${userType}`);
}
deleteusers(userId : string):Observable<any>
{
  return this.http.delete(`http://localhost:9090/admin/deleteuser/${userId}`);
}
getProducts():Observable<any>
{
  return this.http.get(`http://localhost:9090/admin/viewallproducts`);
}
createUser(login : Login,user : UserProfile):Observable<any>
{
return this.http.post(`http://localhost:9090/admin/createuser/${name}`,{login,user},{responseType:'text'});
}
deleteproduct(productId : number)
{
  return this.http.delete(`http://localhost:9090/admin/deleteproduct/${productId}`);

}
public signUpMerchant(userprofile : any, password : String) : Observable<any>
{
  return this.http.post("http://localhost:9090/merchant/signup/"+password,userprofile,{responseType :'text'})
}


public giveFeedback(feedback : Feedback,productId : number) : Observable<any>
  {
    return this.http.post("http://localhost:9090/order/givefeedback/"+productId,feedback,{responseType : 'text'});
  }

}





