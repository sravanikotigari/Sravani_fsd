import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addproducttocart',
  templateUrl: './addproducttocart.component.html',
  styleUrls: ['./addproducttocart.component.css']
})
export class AddproducttocartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
