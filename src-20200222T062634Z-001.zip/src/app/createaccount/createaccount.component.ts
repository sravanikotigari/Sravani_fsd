import { Component, OnInit } from '@angular/core';
import { UserProfile } from '../userprofile';
import { CapstoreserviceService } from '../capstoreservice.service';

@Component({
  selector: 'app-createaccount',
  templateUrl: './createaccount.component.html',
  styleUrls: ['./createaccount.component.css']
})
export class CreateaccountComponent implements OnInit {

  customer:UserProfile=new UserProfile();
  message:string;
  status:boolean;
  password:string;
  reenter_password:string;
  error:string;
  flag=false;
  
  constructor(private service:CapstoreserviceService) { }

  ngOnInit() {
  }
 
  createCustomerProfile()
  {
    this.status=true;
    if(this.password!=this.reenter_password)
    {
      // this.flag=true;
       this.message="Password does not match...Try again "
    }else{
        this.service.createcustomerProfile(this.customer,this.password).subscribe(resp=>{
     
           this.message=resp;
        
      });
    }
      
  }

}
