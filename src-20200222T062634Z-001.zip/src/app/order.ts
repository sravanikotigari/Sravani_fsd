import { Cart } from './cart';
import { UserProfile } from './userprofile';

export class OrderBean
{
    orderId : number;
    customerDetails : UserProfile; 
    cart : Cart;
    orderDate : Date;
    orderStatus : string;

}