

export class UserProfile
{

    userId : string;
    userName : string ;
    userMobile : string ;
    userStreet : string;
    userCity : string;
    userState : string;
    userPincode : number;

    setUserId($userId)
    {
        this.userId = $userId
    }
    setUserName($userName)
    {
        this.userName = $userName;
    }
}