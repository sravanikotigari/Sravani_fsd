import { Component, OnInit } from '@angular/core';
import { CapstoreserviceService } from '../capstoreservice.service';
import { Cart } from '../cart';
import { Router } from '@angular/router';
import { OrderBean } from '../order';
import { SharedService } from 'src/shared.service';

@Component({
  selector: 'app-viewallproductsincart',
  templateUrl: './viewallproductsincart.component.html',
  styleUrls: ['./viewallproductsincart.component.css']
})
export class ViewallproductsincartComponent implements OnInit {

cart : Cart[];
message:string;
userId= sessionStorage.getItem("userid");
status =false;  
constructor(private service :CapstoreserviceService,  private route : Router,private data : SharedService ) {   }

  ngOnInit() {    
    this.service.viewAllProductInCart(this.userId).subscribe(resp=>
      {
        this.cart=resp
        if(this.cart.length<=0)
      {
        this.status=true;
        this.message="No Product Found in Cart for the User Id"+this.userId;
      }
      else
      {
       this.cart=resp;
      }
      }
      );
  }
  
  updateProductQuantityInCart(items:Cart)
  {

    this.service.updateProductQuantityInCart(items.cartId,items.productQuantity).subscribe(resp=>{
      this.message=resp;
      alert(resp);
   
    });
  }


  deleteProductFromCart(items : Cart )
  {
    this.service.deleteProduct(items.product.productId,items.customerDetails.userId).subscribe(resp=>{
      if(resp['errorMessage']!=undefined)
      {
        this.message=resp['errorMessage'];
      }
      else{
        
        this.message=resp;
        alert(this.message);
        this.cart = this.cart.filter(p=>p.cartId!=items.cartId);
     }
    });
}
order : OrderBean = new OrderBean();


placeOrder(items : Cart )
{
  console.log(items);
  this.data.setCart(items);
  this.route.navigate(["/order"]);
}


}
