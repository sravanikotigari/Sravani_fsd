import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallproductsincartComponent } from './viewallproductsincart.component';

describe('ViewallproductsincartComponent', () => {
  let component: ViewallproductsincartComponent;
  let fixture: ComponentFixture<ViewallproductsincartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewallproductsincartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallproductsincartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
