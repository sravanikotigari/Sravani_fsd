import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/product';
import { CapstoreserviceService } from 'src/app/capstoreservice.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
flag :boolean;
  product : Product[];
  constructor(private service : CapstoreserviceService) { }

  ngOnInit() {
    this.getdetails();
  }
  delete(productId : number)
  {
    alert("Are you sure, you want to delete ?");
    this.service.DeleteProduct(productId).subscribe(
      (data) =>
      {
        console.log(data);
        this.getdetails();
      }
    );
  }
  getdetails()
  {
  this.service.getProducts().subscribe(
    (data : Product[]) => {
      if(data != null)
      {
        this.flag=true;
        console.log(data);
        this.product=data;
      }
      else{
        this.flag = false;
      }
   
    }
  );
  }

}
