import { Component, OnInit } from '@angular/core';
import { UserProfile } from '../userprofile';
import { Product } from '../product';
import { CapstoreserviceService } from '../capstoreservice.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  merchant:number;
  customer:number;
  product:number;
  

  constructor(
    private service : CapstoreserviceService
  ) { }

  ngOnInit() {
this.service.getProducts().subscribe(
  (data : Product[]) =>
  {
this.product = data.length;
  }
)
this.service.viewusers('Merchant').subscribe(
  (data : UserProfile[]) =>
  {
this.merchant = data.length;
  }
)
this.service.viewusers('Customer').subscribe(
  (data : UserProfile[]) =>
  {
    console.log(data)
this.customer = data.length;
  }
)
  }

}
