import { Component, OnInit } from '@angular/core';
import { Login } from 'src/app/login';
import { CapstoreserviceService } from 'src/app/capstoreservice.service';
import { UserProfile } from 'src/app/userprofile';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
create : boolean;
  addForm : FormGroup;
userprofile : UserProfile;
name:string;
login : Login;
  constructor(private fb :FormBuilder,
    private service:CapstoreserviceService
    ) { }

  ngOnInit() {
    this.addForm = this.fb.group({
      userId :['',[Validators.required,Validators.email]],
      pass:['',[Validators.required]],
      userType:['',[Validators.required]],
      userName:['',[Validators.required]]
    });
    this.addForm.valueChanges.subscribe(
      (data) => {this.logValidationError()}
    )
  }
  errormessages =
  {
    'pass':
    {
      'required': 'Please Enter password !',
    },
   
    'userType':
    {
      'required': 'Please select user type !',
   },
   'userId':
   {
     'required':'Please Enter userId !',
     'email':'email id is incorrect'
   },
   'userName':
   {
     'required':'Please Enter UserName !'
   }
  }
formErrors =
  {
    'usertype': '',
    'userId':'',
    'pass':'',
    'userName':''
  }
  logValidationError(group: FormGroup = this.addForm): void {
    console.log("validation");
    Object.keys(group.controls).forEach(
      (key: string) => {
        const abstractControl = group.get(key);
        if (abstractControl && !abstractControl.valid
          && (abstractControl.touched || abstractControl.dirty)) {
            const messages = this.errormessages[key];
          for (const errorkey in abstractControl.errors) {
            this.formErrors[key] = '';
            if (errorkey) {
              console.log("error");
              this.formErrors[key] += messages[errorkey] + '';
              console.log(this.formErrors.pass);
            }
          }
        }
      }
    )
  }
  add()
  {
    this.logValidationError();
    if(this.addForm.invalid)
    {
      this.logValidationError();
    }
    else
    {
      this.login = new Login();
      this.userprofile = new UserProfile();
      console.log(this.addForm.get("userId").value);
      this.login.setUserId( this.addForm.get("userId").value);
      this.login.setPassword( this.addForm.get("pass").value);
      this.login.setUserType( this.addForm.get("userType").value);
      this.userprofile.setUserName( this.addForm.get("userName").value);
      this.name = this.addForm.get("userId").value;
      console.log(this.userprofile);
      console.log(this.login);
      
      this.service.createUser(this.login,this.userprofile).subscribe(
        (data) =>{
          this.create = true;
          console.log(data);
          console.log("data reached");
      },
      (error)=>
      {
        console.log(error);
      }
      )    }
  }
}
