import { Component, OnInit } from '@angular/core';
import { UserProfile } from 'src/app/userprofile';
import { CapstoreserviceService } from 'src/app/capstoreservice.service';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {
  user : UserProfile[] = [];
  userId : string;
  userType : string = 'Customer';



  constructor(private service : CapstoreserviceService) { }

  ngOnInit() {
    this.getdetails();
  }
  getid($userId : string)
  {
this.userId = $userId;
console.log($userId);
  }
  delete()
  {
    this.service.deleteusers(this.userId).subscribe(
      (data) =>
      {
        alert("Are you sure, you want to delete ?");
        console.log(data);
        this.getdetails();
      }
    );
  }
  getdetails()
  {
  this.service.viewusers(this.userType).subscribe(
    (data : UserProfile []) => {
      console.log(data);
      this.user=data;
    }
  );
  }}


