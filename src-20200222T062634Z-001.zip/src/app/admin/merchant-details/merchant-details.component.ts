import { Component, OnInit } from '@angular/core';
import { UserProfile } from 'src/app/userprofile';
import { CapstoreserviceService } from 'src/app/capstoreservice.service';

@Component({
  selector: 'app-merchant-details',
  templateUrl: './merchant-details.component.html',
  styleUrls: ['./merchant-details.component.css']
})
export class MerchantDetailsComponent implements OnInit {

  user : UserProfile[] =[];
  userType : string = 'Merchant';



  constructor(private service : CapstoreserviceService) { }

  ngOnInit() {
    this.getdetails();
  }
  delete(userId : string)
  {
    console.log(userId);
    alert("Are you sure you want to delete");
    this.service.deleteusers(userId).subscribe(
      (data) =>
      {
        console.log(data);
        this.getdetails();
      }
    );
  }
  getdetails()
  {
  this.service.viewusers(this.userType).subscribe(
    (data : UserProfile[]) => {
      console.log(data);
      this.user=data;
    }
  );
  }}
