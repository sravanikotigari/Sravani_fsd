import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { CapstoreserviceService } from '../capstoreservice.service';

@Component({
  selector: 'app-listallproduct',
  templateUrl: './listallproduct.component.html',
  styleUrls: ['./listallproduct.component.css']
})
export class ListallproductComponent implements OnInit {

  products:Product[]=[];
  productId:number;
  newproduct:Product=new Product();
  message:any;
  message2:any;
  msg=false;
  status=false;
  display=false;
  show=false;
  status2= false;
  updatemessage:string;
  updatestatus=false;
  visible=true;

    constructor(private service:CapstoreserviceService) { }
  
    ngOnInit() {
    
  this.visible=true;
  let userId=sessionStorage.getItem("userid");
  this.service.listAllProductsById(userId).subscribe(resp=>
    {
      
     
      if(resp['errorMessage']!=undefined)
      {
        this.status=true;
      this.message=resp['errorMessage'];
      
      }
      else
      {
        this.display=true;
        this.products=resp;
      
      }
    });
   
  }
  delete(product)
    {
      if(confirm("Do you want to delete?"))
      {
      this.msg=true;
      this.service.DeleteProduct(product.productId).subscribe(resp=>
        {
           this.message2=resp;
           this.products=this.products.filter((p)=>p.productId!=product.productId);
           
        });
      }
       else
       {
         this.msg=false;
       }  
  
  
    }
    update(products:Product)
    {
      if(confirm("Do you want to update?"))
      {
    this.status2=true;
    this.newproduct=products;
    // this.status=false;
    this.visible=false;
    
    }
    else{
      this.status2=false;
    }
  }
    updateProd(){
       
    this.service.updateProduct(this.newproduct).subscribe(resp=>{
      this.newproduct=resp;
      // this.updatemessage="Update success";
      this.ngOnInit();
      this.updatestatus=true;
      this.status2=false;
    },error=>console.log(error));
    }

}
