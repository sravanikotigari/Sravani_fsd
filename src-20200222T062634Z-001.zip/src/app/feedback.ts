import { Product } from './product';

export class Feedback {
    public feedbackId : number;
    public productId : Product;
    public productRating : number;
    public productReview : string;
    
}