import { Component, OnInit } from '@angular/core';
import { UserProfile } from '../userprofile';
import { CapstoreserviceService } from '../capstoreservice.service';

@Component({
  selector: 'app-viewprofile',
  templateUrl: './viewprofile.component.html',
  styleUrls: ['./viewprofile.component.css']
})
export class ViewprofileComponent implements OnInit {

  status=false;
  status2=false;
  updatestatus=false;
  updatemessage:string;
  merchantProfile : UserProfile = new UserProfile();
  userProfile : UserProfile = new UserProfile();
  constructor(private service : CapstoreserviceService) { }

  ngOnInit() {
    this.status=true;
    let userId=sessionStorage.getItem("userid");
    this.service.viewMerchantprofile(userId).subscribe(resp=>{
      this.userProfile=resp;
    })
  }

  // view()
  // {
    
  // }

  update(userProfile: UserProfile) {
    this.status2 = true;
    this.merchantProfile = userProfile;
    this.status = false;
  }
  updateMerchantProfile() {
     this.service.updateMerchantProfile(this.merchantProfile).subscribe(data => {
      this.merchantProfile = data;
      this.status2=false;
      this.updatestatus = true;
      this.updatemessage = "updated succesfully";
    })
  }



}
