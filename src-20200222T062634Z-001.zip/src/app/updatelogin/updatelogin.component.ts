import { Component, OnInit } from '@angular/core';
import { CapstoreserviceService } from '../capstoreservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updatelogin',
  templateUrl: './updatelogin.component.html',
  styleUrls: ['./updatelogin.component.css']
})
export class UpdateloginComponent implements OnInit {
  newPassword:string;
  message:any;
  status=false;
  
    constructor(private service:CapstoreserviceService,private route:Router) { }
  
    ngOnInit() {
    }
    changePassword()
    {
    let userId=sessionStorage.getItem("userid");
    
  
  
  
      this.service.updateLogin(userId,this.newPassword).subscribe((res)=>
      {
  
        if(res['errorMessage']!=undefined)
        {
          this.message=res['errorMessage'];
          this.status=false;
       alert(this.message);
        }
        else{
          this.message=res;
          this.status=true;
          alert(this.message);
        }
      });
  }
}
