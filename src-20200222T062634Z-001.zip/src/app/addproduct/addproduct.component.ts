import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { CapstoreserviceService } from '../capstoreservice.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  product:Product=new Product();
  message:any;
  status=false;

  constructor(private service:CapstoreserviceService) { }
 
  ngOnInit() {
    
  }
  addNewProduct()
  {
    let userId=sessionStorage.getItem("userid");
    this.product.merchantDetails.userId=userId;
    this.status=true;
    this.service.addProduct(this.product).subscribe(resp=>
      {
         if(resp['errorMessage']!=undefined)
         {
           this.message=resp['errorMessage'];
         }
         else
         {
          this.message=resp;
          
         }

         
      });
  }

}
