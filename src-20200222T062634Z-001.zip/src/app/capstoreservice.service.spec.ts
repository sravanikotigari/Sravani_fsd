import { TestBed } from '@angular/core/testing';

import { CapstoreserviceService } from './capstoreservice.service';

describe('CapstoreserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CapstoreserviceService = TestBed.get(CapstoreserviceService);
    expect(service).toBeTruthy();
  });
});
