export class CapstoreWebURL{

    static readonly URL : string = "http://localhost:9090";

}