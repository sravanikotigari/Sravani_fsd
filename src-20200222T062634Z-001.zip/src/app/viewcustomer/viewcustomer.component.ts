import { Component, OnInit } from '@angular/core';
import { UserProfile } from '../userprofile';
import { CapstoreserviceService } from '../capstoreservice.service';

@Component({
  selector: 'app-viewcustomer',
  templateUrl: './viewcustomer.component.html',
  styleUrls: ['./viewcustomer.component.css']
})
export class ViewcustomerComponent implements OnInit {

  userId:string = sessionStorage.getItem("userid");
  flag=false;
  message:string;
  status=false;
  profile:UserProfile=new UserProfile();
  constructor(private service:CapstoreserviceService) { }

  ngOnInit() {
    console.log(this.userId);
    this.status=true;
    console.log(this.userId);
    this.service.getCustomerDetails(this.userId).subscribe(data=>{
      console.log(data);
      this.profile=data as UserProfile;
    })

  }

  updateCustomerProfile(){
    this.flag=true;
    this.service.updateUserDetails(this.userId,this.profile).subscribe(response=>{
      this.message=response;
    })
  }


}
