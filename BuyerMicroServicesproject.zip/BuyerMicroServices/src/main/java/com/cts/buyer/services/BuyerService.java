package com.cts.buyer.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.repository.IAddressRepository;
import com.cts.buyer.repository.IBuyerRepository;

@Service
public class BuyerService {
	
	@Autowired
	private IBuyerRepository buyerRepository;
	
	@Autowired
	private IAddressRepository addressRepository;
	public BuyerInfo addBuyer(BuyerInfo buyer) {
		addressRepository.save(buyer.getBuyerAddress());
		return buyerRepository.save(buyer);
	}

}
