package com.cts.buyer.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class BuyerInfo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer buyerId;
	private String buyerName;
	private String password;
	private String buyerEmail;
	@OneToOne
	@JoinColumn(name = "buyerAddress")
	private Address buyerAddress;
	private Long buyerMobileNumberPrimary;
	private Long buyerMobileNumberSecondary;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private Date createdDateTime;
	
	
	public BuyerInfo() {
		super();
	}


	public BuyerInfo(Integer buyerId, String buyerName, String password, String buyerEmail, Address buyerAddress,
			Long buyerMobileNumberPrimary, Long buyerMobileNumberSecondary, Date createdDateTime) {
		super();
		this.buyerId = buyerId;
		this.buyerName = buyerName;
		this.password = password;
		this.buyerEmail = buyerEmail;
		this.buyerAddress = buyerAddress;
		this.buyerMobileNumberPrimary = buyerMobileNumberPrimary;
		this.buyerMobileNumberSecondary = buyerMobileNumberSecondary;
		this.createdDateTime = createdDateTime;
	}


	public Integer getBuyerId() {
		return buyerId;
	}


	public void setBuyerId(Integer buyerId) {
		this.buyerId = buyerId;
	}


	public String getBuyerName() {
		return buyerName;
	}


	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getBuyerEmail() {
		return buyerEmail;
	}


	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}


	public Address getBuyerAddress() {
		return buyerAddress;
	}


	public void setBuyerAddress(Address buyerAddress) {
		this.buyerAddress = buyerAddress;
	}


	public Long getBuyerMobileNumberPrimary() {
		return buyerMobileNumberPrimary;
	}


	public void setBuyerMobileNumberPrimary(Long buyerMobileNumberPrimary) {
		this.buyerMobileNumberPrimary = buyerMobileNumberPrimary;
	}


	public Long getBuyerMobileNumberSecondary() {
		return buyerMobileNumberSecondary;
	}


	public void setBuyerMobileNumberSecondary(Long buyerMobileNumberSecondary) {
		this.buyerMobileNumberSecondary = buyerMobileNumberSecondary;
	}


	public Date getCreatedDateTime() {
		return createdDateTime;
	}


	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
}
