package com.cts.buyer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.entity.CartItems;

@Repository
public interface ICartRepository extends JpaRepository<CartItems, Integer>{
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM cart_items cart WHERE cart.buyer_id = :buyerId", nativeQuery = true)
	public void deleteBybuyer(@Param("buyerId")Integer buyerId);
	@Query(value = "SELECT * FROM cart_items cart WHERE cart.buyer_id = :buyerId", nativeQuery = true)
	public List<CartItems> findAllCartItem(@Param("buyerId")Integer buyerId); 
}
