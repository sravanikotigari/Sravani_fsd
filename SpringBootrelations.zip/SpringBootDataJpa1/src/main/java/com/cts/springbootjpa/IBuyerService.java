package com.cts.springbootjpa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface IBuyerService {
	
	List<BuyerDb> getAllBuyers();
	
	BuyerDb getByUsername(String name);
	
	 
		
//	 BuyerDb getByusername(String name) {
//		return null;
//	} 
	 
//	 Person findUsingNameAddress(String name, String addr);
	 
	 Integer createOrUpdate(BuyerDb buyerservice);
	 
	 void deleteById(Integer buyerId);
	 
	 BuyerDb update (BuyerDb buyerservice);
	 
	 BuyerDb updateAddr(BuyerDb buyerservice);

	BuyerDb updatepassword(BuyerDb buyerservice);

	
	
}


