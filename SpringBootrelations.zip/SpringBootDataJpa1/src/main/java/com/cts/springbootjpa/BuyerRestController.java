package com.cts.springbootjpa;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BuyerRestController {
	
	@Autowired
	private IBuyerService buyerservice;
	
	
	@RequestMapping("getAll")
	public List<BuyerDb> getAll(){
	
		return buyerservice.getAllBuyers();
	}
	
	@RequestMapping("getByUsername/{busername}")
	public BuyerDb getPersonByName(@PathVariable("busername") String name){
		
		return buyerservice.getByUsername(name);
	}
	@RequestMapping(value = "/buyer", method = RequestMethod.POST, produces = "application/json")
	public Integer createOrUpdate (@RequestBody BuyerDb buyer) {
		
		return buyerservice.createOrUpdate(buyer);
	}
	
	@RequestMapping(value = "deleteById/{bid}", method = RequestMethod.DELETE)
	public void deleteById(@PathVariable("bid") Integer buyerid) {
		
		buyerservice.deleteById(buyerid);
	}
	
	@RequestMapping(value="/update", method = RequestMethod.PUT)
	public BuyerDb updatePerson(@RequestBody BuyerDb buyer) {
		
		return buyerservice.update(buyer);
	}
	
	@RequestMapping(value="/updateAddr", method = RequestMethod.PATCH)
	public BuyerDb updatePersonAddr(@RequestBody BuyerDb buyer) {
		
		return buyerservice.updateAddr(buyer);
	}
}
