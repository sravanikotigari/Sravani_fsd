package com.cts.springbootjpa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

public interface IBuyerDbDao extends JpaRepository<BuyerDb, Integer> {
	
	@Query(value = "FROM BuyerDb b WHERE b.'buyerusername'=:bname")
	public BuyerDb findByUsername(@Param("bname") String username);

}
