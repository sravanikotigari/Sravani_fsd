package com.cts.springbootjpa;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
//@Table(name="Buyer_details")
public class BuyerDb implements Serializable {
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int buyerid;
	@Column(name="User_Name")
	private String username;
	private String password;
	@Column(name="Mobile_No")
	private long mobileno;
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date createddatatime;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "Buyer_id")
	private List<PurchaseHistory> purchasehistory;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "BUYER_ID")
	private List<Transcations> transcations;

	public BuyerDb() {
		
	}

	public BuyerDb(int buyerid, String username, String password, long mobileno, Date createddatatime) {
		super();
		this.buyerid = buyerid;
		this.username = username;
		this.password = password;
		this.mobileno = mobileno;
		this.createddatatime = createddatatime;
	}

	public int getBuyerid() {
		return buyerid;
	}

	public void setBuyerid(int buyerid) {
		this.buyerid = buyerid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword() {
		this.password = password;
	}

	public long getMobileno() {
		return mobileno;
	}

	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}

	public Date getCreateddatatime() {
		return createddatatime;
	}

	public void setCreateddatatime(Date createddatatime) {
		this.createddatatime = createddatatime;
	}
	

	public List<PurchaseHistory> getPurchasehistory() {
		return purchasehistory;
	}

	public void setPurchasehistory(List<PurchaseHistory> purchasehistory) {
		this.purchasehistory = purchasehistory;
	}
	
	

	public List<Transcations> getTranscations() {
		return transcations;
	}

	public void setTranscations(List<Transcations> transcations) {
		this.transcations = transcations;
	}

	@Override
	public String toString() {
		return "BuyerDb [buyerid=" + buyerid + ", username=" + username + ", password=" + password + ", mobileno="
				+ mobileno + ", createddatatime=" + createddatatime + "]";
	}

	

}
