package com.cts;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;


import com.cts.Productmodel;

@Repository
public class Productdao extends JdbcDaoSupport{
	
	public int addProduct(Productmodel product) {
		int storedStatus=getJdbcTemplate().update("INSERT INTO product values(?,?,?,?)",new Object[]{product. getProductId(),product. getProductName(),product.getQuantity(),product.getProductDescription()});
		System.out.println(storedStatus);
		return product.getProductId();
	}

	public int deleteProduct(int productId) {
		
		int deletedStatus=getJdbcTemplate().update("DELETE from product WHERE product_id = ?",new Object[]{productId});
		System.out.println(deletedStatus);
		return deletedStatus;
	}

	public int updateProduct(Productmodel product) {
		int updateStatus=getJdbcTemplate().update("UPDATE product set product_name = ? , product_quantity = ? , product_description = ? where product_id = ?",new Object[]{product. getProductId(),product. getProductName(),product.getQuantity(),product.getProductDescription()});
	//	System.out.println(updateStatus);
		return updateStatus;
	}

	public Productmodel getProductById(int productId) {
		   Productmodel product = getJdbcTemplate().queryForObject("SELECT * FROM product WHERE product_id = ?",
				     new Object[] { productId }, new BeanPropertyRowMapper<Productmodel>(Productmodel.class));
		return product;
	}

	

	

}
