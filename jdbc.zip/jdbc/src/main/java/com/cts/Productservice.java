package com.cts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Productdao;
import com.cts.Productmodel;

@Service
public class Productservice {
	
	@Autowired
	private Productdao productDao;
public int addProduct(Productmodel product){
		
		return productDao.addProduct(product);
	}

	
	public Productmodel getProductById(int productId)
	{
		Productmodel product = productDao.getProductById(productId);
		return product;
	}
	
	public int updateProduct(Productmodel product)
	{
		return productDao.updateProduct(product);
	}
	
	public int deleteProduct(int productId)
	{
		return productDao.deleteProduct(productId);
	}
	
	
	
	

}
