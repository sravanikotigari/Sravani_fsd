package com.example.jpa.repository;

import com.example.jpa.model.Comment2;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


@Repository
public interface CommentRepository2 extends JpaRepository<Comment2, Long> {
    Page<Comment2> findByPostId(Long postId, Pageable pageable);
    Optional<Comment2> findByIdAndPostId(Long id, Long postId);
}
