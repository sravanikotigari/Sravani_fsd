package com.example.jpa.controller;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.Comment2;
import com.example.jpa.repository.CommentRepository2;
import com.example.jpa.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class CommentController2 {

    @Autowired
    private CommentRepository2 commentRepository2;

    @Autowired
    private PostRepository postRepository;

    @GetMapping("/posts/{postId}/comments2")
    public Page<Comment2> getAllCommentsByPostId(@PathVariable (value = "postId") Long postId,
                                                Pageable pageable) {
        return commentRepository2.findByPostId(postId, pageable);
    }

    @PostMapping("/posts/{postId}/comments2")
    public Comment2 createComment(@PathVariable (value = "postId") Long postId,
                                 @Valid @RequestBody Comment2 comment2) {
        return postRepository.findById(postId).map(post -> {
            comment2.setPost(post);
            return commentRepository2.save(comment2);
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
    }

    @PutMapping("/posts/{postId}/comments2/{commentId}")
    public Comment2 updateComment(@PathVariable (value = "postId") Long postId,
                                 @PathVariable (value = "commentId") Long commentId,
                                 @Valid @RequestBody Comment2 commentRequest) {
        if(!postRepository.existsById(postId)) {
            throw new ResourceNotFoundException("PostId " + postId + " not found");
        }

        return commentRepository2.findById(commentId).map(comment2 -> {
            comment2.setText(commentRequest.getText());
            return commentRepository2.save(comment2);
        }).orElseThrow(() -> new ResourceNotFoundException("CommentId " + commentId + "not found"));
    }

    @DeleteMapping("/posts/{postId}/comments2/{commentId}")
    public ResponseEntity<?> deleteComment(@PathVariable (value = "postId") Long postId,
                              @PathVariable (value = "commentId") Long commentId) {
        return commentRepository2.findByIdAndPostId(commentId, postId).map(comment2 -> {
            commentRepository2.delete(comment2);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Comment not found with id " + commentId + " and postId " + postId));
    }
}
