package com.javasampleapproach.springrest.mysql.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javasampleapproach.springrest.mysql.model.Customer;
import com.javasampleapproach.springrest.mysql.repo.CustomerRepository;

@Service
public class CustomerService  {
	
	@Autowired
	
	public CustomerRepository repoistory;
		 Iterable<Customer> getCustomers(){
			 return repoistory.findAll();
		 }
	

}
